import UIKit
import SceneKit

struct MallItem {
    enum Kind { case phone,key,radio,map,battery,coin,fuse,locker,counter,vent,camera,generator,exit,arcade }
    let id: String; let kind: Kind; let title: String; let point: Point
    let node: SCNNode
    var collected=false
    var hiding: Bool { kind == .locker || kind == .counter || kind == .vent }
}
final class MallScene {
    let scene=SCNScene()
    let layout=MallLayout()
    var items:[MallItem]=[]
    var mainLights:[SCNLight]=[]
    var emergencyLights:[SCNLight]=[]
    let ambient=SCNLight()
    let player=SCNNode(),head=SCNNode(),camera=SCNNode(),torch=SCNNode()
    let securityCamera=SCNNode()
    var guardNodes:[SCNNode]=[]
    let monster=SCNNode()
    let floorMaterial=SCNMaterial()
    private var materials:[String:SCNMaterial]=[:]

    init() {
        scene.background.contents=UIColor(red:0.018,green:0.023,blue:0.028,alpha:1)
        scene.fogColor=UIColor(red:0.02,green:0.025,blue:0.03,alpha:1)
        scene.fogStartDistance=15;scene.fogEndDistance=49
        ambient.type = .ambient;ambient.color=UIColor(red:0.30,green:0.39,blue:0.45,alpha:1);ambient.intensity=180
        let ambientNode=SCNNode();ambientNode.light=ambient;scene.rootNode.addChildNode(ambientNode)
        buildArchitecture();buildShops();buildItems();buildActors()
        player.position=SCNVector3(0,0,-31)
        head.position.y=1.63;player.addChildNode(head);head.addChildNode(camera)
        camera.camera=SCNCamera();camera.camera?.fieldOfView=72
        camera.camera?.zNear=0.06;camera.camera?.zFar=90
        camera.camera?.wantsHDR=true;camera.camera?.exposureOffset = -0.2
        camera.camera?.bloomIntensity=0.22;camera.camera?.bloomThreshold=1
        camera.camera?.vignettingIntensity=0.7;camera.camera?.vignettingPower=0.5
        torch.light=SCNLight();torch.light?.type = .spot
        torch.light?.color=UIColor(red:1,green:0.91,blue:0.73,alpha:1)
        torch.light?.intensity=1100;torch.light?.spotInnerAngle=22;torch.light?.spotOuterAngle=58
        torch.light?.attenuationStartDistance=2;torch.light?.attenuationEndDistance=23
        torch.light?.castsShadow=true;torch.light?.shadowMapSize=CGSize(width:512,height:512)
        torch.light?.shadowRadius=3;torch.light?.shadowSampleCount=4
        torch.position=SCNVector3(0.18,-0.12,-0.10);camera.addChildNode(torch)
        let body=box(0.10,0.10,0.32,mat("torch",UIColor(white:0.07,alpha:1),metal:0.75),at:SCNVector3(0.29,-0.27,-0.42),parent:camera)
        body.eulerAngles.x = -0.08
        let lens=SCNNode(geometry:SCNCylinder(radius:0.07,height:0.035));lens.geometry?.firstMaterial=mat("lens",.darkGray,metal:0.9);lens.position=SCNVector3(0.29,-0.27,-0.59);lens.eulerAngles.x = .pi/2;camera.addChildNode(lens)
        scene.rootNode.addChildNode(player)
        securityCamera.camera=SCNCamera();securityCamera.camera?.fieldOfView=85
        securityCamera.position=SCNVector3(0,4,2);securityCamera.eulerAngles=SCNVector3(-0.25,0,0);scene.rootNode.addChildNode(securityCamera)
    }
    func mat(_ key: String,_ color: UIColor,metal: CGFloat=0,rough:CGFloat=0.7) -> SCNMaterial {
        if let m=materials[key] { return m }
        let m=SCNMaterial();m.lightingModel = .physicallyBased;m.diffuse.contents=color;m.metalness.contents=metal;m.roughness.contents=rough;materials[key]=m;return m
    }
    @discardableResult func box(_ w:CGFloat,_ h:CGFloat,_ d:CGFloat,_ material:SCNMaterial,at p:SCNVector3,parent:SCNNode?=nil) -> SCNNode {
        let g=SCNBox(width:w,height:h,length:d,chamferRadius:min(0.025,min(w,h,d)*0.04));g.firstMaterial=material
        let n=SCNNode(geometry:g);n.position=p;(parent ?? scene.rootNode).addChildNode(n);return n
    }
    func painted(_ text:String,bg:UIColor,fg:UIColor = .white,size:CGSize=CGSize(width:640,height:160)) -> UIImage {
        UIGraphicsImageRenderer(size:size).image { c in
            bg.setFill();c.fill(CGRect(origin:.zero,size:size))
            let paragraph=NSMutableParagraphStyle();paragraph.alignment = .center
            let font=UIFont.systemFont(ofSize: min(64,size.height*0.45),weight:.bold)
            let attrs:[NSAttributedString.Key:Any]=[.font:font,.foregroundColor:fg,.paragraphStyle:paragraph]
            (text as NSString).draw(in:CGRect(x:8,y:(size.height-font.lineHeight)/2,width:size.width-16,height:font.lineHeight+6),withAttributes:attrs)
        }
    }
    func sign(_ text:String,at p:SCNVector3,width:CGFloat=5,height:CGFloat=0.9,rotation:Float=0,color:UIColor = .darkGray,glow:Bool=false) {
        let g=SCNPlane(width:width,height:height),m=SCNMaterial();let texture=painted(text,bg:color)
        m.diffuse.contents=texture;m.isDoubleSided=true
        if glow {m.emission.contents=texture;m.emission.intensity=0.8}
        g.firstMaterial=m;let n=SCNNode(geometry:g);n.position=p;n.eulerAngles.y=rotation;scene.rootNode.addChildNode(n)
    }
    func buildArchitecture() {
        let tile=UIGraphicsImageRenderer(size:CGSize(width:256,height:256)).image { c in
            UIColor(white:0.28,alpha:1).setFill();c.fill(CGRect(x:0,y:0,width:256,height:256))
            for i in 0..<90 {
                let x=(i*83)%256,y=(i*137)%256
                UIColor(white:CGFloat(0.24+Double(i%9)*0.01),alpha:0.6).setFill();c.fill(CGRect(x:CGFloat(x),y:CGFloat(y),width:40,height:2))
            }
            UIColor(white:0.08,alpha:1).setStroke();let path=UIBezierPath(rect:CGRect(x:1,y:1,width:254,height:254));path.lineWidth=3;path.stroke()
        }
        floorMaterial.lightingModel = .physicallyBased;floorMaterial.diffuse.contents=tile
        floorMaterial.diffuse.wrapS = .repeat;floorMaterial.diffuse.wrapT = .repeat
        floorMaterial.diffuse.contentsTransform=SCNMatrix4MakeScale(26,38,1)
        floorMaterial.metalness.contents=0.35;floorMaterial.roughness.contents=0.22
        box(54,0.18,78,floorMaterial,at:SCNVector3(0,-0.13,0))
        let concrete=mat("concrete",UIColor(red:0.29,green:0.31,blue:0.32,alpha:1))
        box(54,0.25,78,mat("ceiling",UIColor(white:0.12,alpha:1)),at:SCNVector3(0,4.8,0))
        for b in layout.obstacles {box(CGFloat(b.w),b.d < 0.4 || b.w < 0.4 ? 4.6:1.45,CGFloat(b.d),concrete,at:SCNVector3(b.x,b.d < 0.4 || b.w < 0.4 ? 2.3:0.72,b.z))}
        for x:Float in [-26,26] {box(0.4,4.8,78,concrete,at:SCNVector3(x,2.3,0))}
        for z:Float in [-38,38] {box(54,4.8,0.4,concrete,at:SCNVector3(0,2.3,z))}
        // Columns and ceiling ribs establish the scale of the central concourse.
        for z in stride(from:-34,through:34,by:8) {
            for x:Float in [-3.7,3.7] {box(0.22,4.6,0.22,mat("chrome",.gray,metal:0.85,rough:0.3),at:SCNVector3(x,2.3,Float(z)))}
            box(8,0.12,0.18,concrete,at:SCNVector3(0,4.5,Float(z)))
        }
        for z in stride(from:-30,through:30,by:12) {
            ceilingLight(Point(x:0,z:Float(z)),warm:false)
            for x:Float in [-17,17] {ceilingLight(Point(x:x,z:Float(z)),warm:true)}
        }
        for z:Float in [-35,0,35] {
            let n=SCNNode();n.position=SCNVector3(0,3,z);n.light=SCNLight();n.light?.type = .omni;n.light?.color=UIColor.red;n.light?.intensity=65;n.light?.attenuationEndDistance=9;scene.rootNode.addChildNode(n);emergencyLights.append(n.light!)
        }
        for (z,text) in [(-6.0,"← FLIPERAMA    •    ALIMENTAÇÃO →"),(7.0,"← SEGURANÇA       DOCAS / SAÍDA ↑")] {
            sign(text,at:SCNVector3(0,3.55,Float(z)),width:7,height:0.6,color:UIColor(red:0.03,green:0.12,blue:0.12,alpha:1),glow:true)
        }
        // Escalators are closed at night; visible in the centre without blocking the route.
        for x:Float in [-1.8,1.8] {
            for i in 0..<12 { box(1.5,0.12,0.28,mat("escalator",.darkGray,metal:0.8),at:SCNVector3(x,0.16+Float(i)*0.095,-1.65+Float(i)*0.3)) }
        }
        sign("SHOPPING AURORA",at:SCNVector3(0,3.5,-37.6),width:7,color:UIColor(red:0.17,green:0.10,blue:0.06,alpha:1),glow:true)
        sign("DOCAS  /  ACESSO CONTROLADO",at:SCNVector3(0,3,37.5),width:7,color:.darkGray)
    }
    func ceilingLight(_ p:Point,warm:Bool) {
        let m=mat(warm ? "warmPanel":"panel",warm ? UIColor(red:0.7,green:0.57,blue:0.39,alpha:1):UIColor(red:0.65,green:0.80,blue:0.86,alpha:1))
        m.emission.contents=warm ? UIColor(red:0.7,green:0.52,blue:0.28,alpha:1):UIColor(red:0.5,green:0.7,blue:0.8,alpha:1);m.emission.intensity=0.5
        box(2.2,0.05,0.5,m,at:SCNVector3(p.x,4.5,p.z))
        let n=SCNNode();n.position=SCNVector3(p.x,4.1,p.z);n.light=SCNLight();n.light?.type = .omni;n.light?.intensity=warm ? 210:300;n.light?.color=warm ? UIColor(red:1,green:0.72,blue:0.46,alpha:1):UIColor(red:0.65,green:0.83,blue:1,alpha:1);n.light?.attenuationEndDistance=11;scene.rootNode.addChildNode(n);mainLights.append(n.light!)
    }
    func buildShops() {
        let names=[(-4.1,-20.0,"MODA & CIA",UIColor(red:0.27,green:0.08,blue:0.07,alpha:1)),(4.1,-20.0,"MUNDO DOS BRINQUEDOS",UIColor(red:0.04,green:0.19,blue:0.23,alpha:1)),(-4.1,20.0,"PLAY / ARCADE",UIColor(red:0.23,green:0.05,blue:0.27,alpha:1)),(4.1,20.0,"PRAÇA DE ALIMENTAÇÃO",UIColor(red:0.24,green:0.17,blue:0.04,alpha:1))]
        for (x,z,text,color) in names {sign(text,at:SCNVector3(Float(x),3.2,Float(z)),width:8,height:0.8,rotation:x<0 ? .pi/2 : -.pi/2,color:color)}
        for x:Float in [-21,-18,-11,-8] {
            for z:Float in [-30,-24] {
                box(2.0,0.05,0.8,mat("rack",.gray,metal:0.8),at:SCNVector3(x,1.65,z))
                for i in 0..<5 {box(0.26,0.9,0.45,mat("cloth\(i)",[UIColor.brown,.darkGray,.gray,.systemTeal,.systemBrown][i]),at:SCNVector3(x-0.65+Float(i)*0.32,1.08,z))}
            }
        }
        for x:Float in [9,16,22] {
            for z:Float in [-31,-18] {
                box(2.0,0.12,0.9,mat("shelf",.gray),at:SCNVector3(x,0.5,z))
                box(2.0,0.12,0.9,mat("shelf",.gray),at:SCNVector3(x,1.2,z))
                for i in 0..<3 {box(0.4,0.5,0.4,mat("toy\(i)",[UIColor.systemRed,.systemYellow,.systemBlue][i]),at:SCNVector3(x-0.6+Float(i)*0.6,1.5,z))}
            }
        }
        for x:Float in [-22,-18,-10,-6] {
            for z:Float in [17,31] {
                let n=box(1,1.6,0.9,mat("arcade",UIColor(white:0.045,alpha:1)),at:SCNVector3(x,0.8,z));n.eulerAngles.y=z>20 ? 0:.pi
                let screen=mat("arcadeScreen",UIColor(red:0.1,green:0.5,blue:0.5,alpha:1));screen.emission.contents=UIColor.cyan;screen.emission.intensity=0.8
                box(0.75,0.55,0.04,screen,at:SCNVector3(0,0.25,0.48),parent:n)
                box(0.85,0.08,0.45,mat("buttons",.darkGray),at:SCNVector3(0,-0.15,0.6),parent:n)
            }
        }
        for x:Float in [9,17,22] {for z:Float in [14,21,30] {
            box(1.6,0.1,1.2,mat("table",UIColor(white:0.5,alpha:1),metal:0.35),at:SCNVector3(x,0.85,z));box(0.12,0.8,0.12,mat("chrome",.gray),at:SCNVector3(x,0.4,z))
            for dx:Float in [-0.95,0.95] {box(0.5,0.45,0.5,mat("chairs",UIColor(red:0.25,green:0.08,blue:0.05,alpha:1)),at:SCNVector3(x+dx,0.3,z))}
        }}
        sign("CAFÉ  /  FECHADO",at:SCNVector3(16,2.5,33.7),width:6,color:.brown)
        // Security office and loading area's worn storage crates.
        box(4,0.9,1.2,mat("desk",.darkGray),at:SCNVector3(-21,0.45,5.5))
        for x:Float in [-22,-20] {box(1.1,0.8,0.12,mat("monitor",UIColor(red:0.08,green:0.20,blue:0.16,alpha:1)),at:SCNVector3(x,1.35,5.7))}
        sign("SEGURANÇA",at:SCNVector3(-25.7,2.5,2),width:4,rotation:.pi/2,color:.darkGray)
        for x:Float in [16,20,24] {box(1.4,1.4,1.4,mat("crate",UIColor(red:0.24,green:0.17,blue:0.10,alpha:1)),at:SCNVector3(x,0.7,-3.4))}
    }
    func buildItems() {
        func add(_ id:String,_ kind:MallItem.Kind,_ title:String,_ x:Float,_ z:Float) {
            let n=SCNNode();n.position=SCNVector3(x,0,z);scene.rootNode.addChildNode(n)
            let big=kind == .locker || kind == .generator || kind == .exit
            let color:UIColor=kind == .exit ? .darkGray : kind == .locker ? UIColor(white:0.25,alpha:1):UIColor(red:0.65,green:0.44,blue:0.18,alpha:1)
            if kind == .locker {box(0.9,2.1,0.8,mat("locker",color,metal:0.65),at:SCNVector3(0,1.05,0),parent:n)
                for y:Float in [1.5,1.6,1.7] {box(0.5,0.015,0.01,mat("black",.black),at:SCNVector3(0,y,0.411),parent:n)}
            } else if kind == .counter {box(2.5,1.1,1.1,mat("counter",.brown),at:SCNVector3(0,0.55,0),parent:n)}
            else if kind == .vent {box(1,0.7,1,mat("vent",.gray,metal:0.8),at:SCNVector3(0,0.35,0),parent:n)}
            else if kind == .exit {box(4,3.1,0.25,mat("exit",color,metal:0.7),at:SCNVector3(0,1.55,0),parent:n)}
            else if kind == .camera {box(1,0.7,0.12,mat("terminal",UIColor(red:0.05,green:0.3,blue:0.22,alpha:1)),at:SCNVector3(0,1.25,0),parent:n)}
            else if kind == .generator {box(1.5,1.7,0.7,mat("generator",UIColor(red:0.1,green:0.24,blue:0.2,alpha:1),metal:0.6),at:SCNVector3(0,0.85,0),parent:n)}
            else if kind == .arcade {box(0.7,1.2,0.7,mat("ride",.systemRed),at:SCNVector3(0,0.6,0),parent:n)}
            else {
                let dimensions:SCNVector3=kind == .phone ? SCNVector3(0.14,0.02,0.27):kind == .map ? SCNVector3(0.36,0.02,0.28):SCNVector3(0.14,0.22,0.14)
                let m=mat("item_\(id)",color,metal:0.5);m.emission.contents=UIColor(red:0.4,green:0.25,blue:0.06,alpha:1);m.emission.intensity=0.5
                box(CGFloat(dimensions.x),CGFloat(dimensions.y),CGFloat(dimensions.z),m,at:SCNVector3(0,0.85,0),parent:n)
                box(0.65,0.75,0.65,mat("pedestal",UIColor(white:0.1,alpha:1)),at:SCNVector3(0,0.375,0),parent:n)
                let ring=SCNNode(geometry:SCNTorus(ringRadius:0.25,pipeRadius:0.009));ring.geometry?.firstMaterial=m;ring.position.y=1.15;n.addChildNode(ring)
                ring.runAction(.repeatForever(.rotateBy(x:0,y:2*CGFloat.pi,z:0,duration:3)))
            }
            if big && kind != .exit {sign(title.uppercased(),at:SCNVector3(x,2.5,z),width:2.2,height:0.35,color:.darkGray)}
            items.append(MallItem(id:id,kind:kind,title:title,point:Point(x:x,z:z),node:n))
        }
        add("phone",.phone,"Celular da Lia",20,18)
        add("key",.key,"Chave das docas",-21,-18)
        add("radio",.radio,"Rádio do vigilante",22,1)
        add("map",.map,"Mapa do shopping",-6,-18)
        add("fuse1",.fuse,"Fusível",8,-22);add("fuse2",.fuse,"Fusível",-19,19)
        for (i,p) in [Point(x:-8,z:-31),Point(x:21,z:-14),Point(x:8,z:32),Point(x:-22,z:12),Point(x:1,z:26)].enumerated() {add("battery\(i)",.battery,"Bateria",p.x,p.z)}
        for (i,p) in [Point(x:2,z:-24),Point(x:-10,z:20),Point(x:8,z:12),Point(x:1,z:8)].enumerated() {add("coin\(i)",.coin,"Moedas",p.x,p.z)}
        add("locker1",.locker,"Armário",-22,-12);add("locker2",.locker,"Armário",22,-31)
        add("locker3",.locker,"Armário",-22,22);add("counter",.counter,"Balcão",22,31)
        add("vent",.vent,"Tubulação",3,30)
        add("cctv",.camera,"Câmeras de segurança",-20,4)
        add("generator",.generator,"Quadro de energia",24,-1)
        add("exit",.exit,"Portas de carga",0,36)
        add("ride",.arcade,"Brinquedo mecânico",8,-12)
    }
    func buildActors() {
        for i in 0..<2 {
            let root=SCNNode(),uniform=mat("uniform",UIColor(red:0.045,green:0.065,blue:0.08,alpha:1))
            box(0.5,0.7,0.3,uniform,at:SCNVector3(0,1.1,0),parent:root)
            for x:Float in [-0.16,0.16] {box(0.17,0.75,0.21,uniform,at:SCNVector3(x,0.4,0),parent:root)}
            let head=SCNNode(geometry:SCNSphere(radius:0.19));head.position.y=1.65;head.geometry?.firstMaterial=mat("skin",UIColor(red:0.40,green:0.31,blue:0.23,alpha:1));root.addChildNode(head)
            box(0.44,0.1,0.4,uniform,at:SCNVector3(0,1.82,0),parent:root)
            box(0.15,0.48,0.14,uniform,at:SCNVector3(-0.32,1.05,0),parent:root)
            box(0.15,0.2,0.5,uniform,at:SCNVector3(0.31,1.25,-0.23),parent:root)
            let light=SCNNode();light.position=SCNVector3(0.3,1.35,-0.5);light.light=SCNLight();light.light?.type = .spot;light.light?.intensity=1000;light.light?.spotInnerAngle=18;light.light?.spotOuterAngle=48;light.light?.attenuationEndDistance=17;light.light?.color=UIColor(red:1,green:0.88,blue:0.62,alpha:1);root.addChildNode(light)
            root.position=SCNVector3(i==0 ? 0:-18,0,i==0 ? -8:20);scene.rootNode.addChildNode(root);guardNodes.append(root)
        }
        let rust=mat("rust",UIColor(red:0.23,green:0.16,blue:0.10,alpha:1),metal:0.55,rough:0.8)
        let bone=mat("bone",UIColor(red:0.48,green:0.43,blue:0.31,alpha:1),metal:0.12)
        box(0.7,0.9,0.4,bone,at:SCNVector3(0,1.45,0),parent:monster)
        box(0.5,0.35,0.35,rust,at:SCNVector3(0,0.85,0),parent:monster)
        let skull=SCNNode(geometry:SCNSphere(radius:0.38));skull.scale=SCNVector3(1,1.1,0.82);skull.position=SCNVector3(0,2.22,0);skull.geometry?.firstMaterial=bone;monster.addChildNode(skull)
        for x:Float in [-0.29,0.29] {
            let ear=SCNNode(geometry:SCNTorus(ringRadius:0.13,pipeRadius:0.055));ear.eulerAngles.x = .pi/2;ear.position=SCNVector3(x,2.6,0);ear.geometry?.firstMaterial=rust;monster.addChildNode(ear)
            box(0.16,0.8,0.15,rust,at:SCNVector3(x*1.65,1.3,-0.04),parent:monster)
            box(0.13,0.65,0.13,bone,at:SCNVector3(x*1.95,0.67,-0.12),parent:monster)
            for j in 0..<3 {box(0.035,0.25,0.035,rust,at:SCNVector3(x*1.95+Float(j-1)*0.055,0.27,-0.14),parent:monster)}
            box(0.18,0.7,0.18,rust,at:SCNVector3(x,0.4,0),parent:monster)
            let eye=SCNNode(geometry:SCNSphere(radius:0.065));eye.position=SCNVector3(x*0.5,2.29,-0.29)
            let red=mat("eyes",.red);red.emission.contents=UIColor.red;red.emission.intensity=2;eye.geometry?.firstMaterial=red;monster.addChildNode(eye)
        }
        box(0.45,0.16,0.1,mat("mouth",.black),at:SCNVector3(0,2.03,-0.31),parent:monster)
        for i in 0..<8 {box(0.033,0.07,0.03,bone,at:SCNVector3(Float(i)*0.052-0.18,2.05,-0.37),parent:monster)}
        monster.position=SCNVector3(-18,0,22);monster.isHidden=true;scene.rootNode.addChildNode(monster)
    }
    func applyLighting(state:RunState,time:Double) {
        let night=state.phase != .closing
        let flicker:CGFloat=state.blackout ? 0 : (night ? (sin(time*31)>0.97 ? 0.15:0.30):1)
        for (i,l) in mainLights.enumerated() {l.intensity = (i%3 == 0 ? 300:210)*flicker}
        ambient.intensity=state.blackout ? 12 : night ? 55:180
        for l in emergencyLights {l.intensity=night ? 75:15}
        torch.light?.intensity=state.flashlight && state.battery>0 && !state.hidden ? (state.battery < 15 && sin(time*19)>0.6 ? 250:1100):0
        for n in guardNodes {n.isHidden=night}
        monster.isHidden = !night
        scene.fogStartDistance=state.blackout ? 8:15
        for k in ["panel","warmPanel"] {materials[k]?.emission.intensity=CGFloat(flicker)*0.5}
    }
}
