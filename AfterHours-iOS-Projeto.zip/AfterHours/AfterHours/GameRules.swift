import Foundation

struct Point: Equatable, Hashable {
    var x: Float
    var z: Float
    static func + (a: Point, b: Point) -> Point { Point(x: a.x+b.x, z: a.z+b.z) }
    static func - (a: Point, b: Point) -> Point { Point(x: a.x-b.x, z: a.z-b.z) }
    static func * (a: Point, b: Float) -> Point { Point(x: a.x*b, z: a.z*b) }
    var length: Float { sqrt(x*x+z*z) }
    func distance(_ other: Point) -> Float { (self-other).length }
    var normalized: Point { length > 0.001 ? self * (1/length) : Point(x: 0,z: 0) }
}
struct Block {
    let x: Float; let z: Float; let w: Float; let d: Float
    func contains(_ p: Point, margin: Float = 0) -> Bool {
        abs(p.x-x) < w/2+margin && abs(p.z-z) < d/2+margin
    }
}
enum NightPhase { case closing, night, escaped, caught }
enum Difficulty: Int, CaseIterable {
    case quiet, normal, nightmare
    var title: String { ["Exploração", "Normal", "Pesadelo"][rawValue] }
    var closingDuration: Double { [45,65,80][rawValue] }
    var nightDuration: Double { [270,360,420][rawValue] }
    var enemySpeed: Float { [1.45,2.15,2.65][rawValue] }
    var detectionRate: Double { [0.32,0.65,0.95][rawValue] }
    var batteryDrain: Float { [0.55,0.85,1.1][rawValue] }
}
struct RunState {
    var phase: NightPhase = .closing
    var elapsed: Double = 0
    var nightTime: Double = 0
    var difficulty: Difficulty = .normal
    var phone = false; var key = false; var radio = false; var map = false
    var fuses = 0; var coins = 2; var batteries = 1
    var battery: Float = 100; var stamina: Float = 100
    var poweredFor: Double = 0
    var hidden = false; var crouched = false; var flashlight = true
    var safeRoomCharge: Double = 28
    var suspicion: Double = 0
    var blackout: Bool { phase == .night && poweredFor <= 0 && nightTime.truncatingRemainder(dividingBy: 70) >= 40 }
    var hour: Int { phase == .closing ? 21 : min(6,Int(nightTime/difficulty.nightDuration*6)) }
    var minute: Int { phase == .closing ? min(59,Int(elapsed/difficulty.closingDuration*59)) : (hour >= 6 ? 0 : min(59,Int(nightTime/difficulty.nightDuration*360)%60)) }
    var canEscape: Bool { phase == .night && hour >= 6 && phone && key && radio }
    mutating func tick(_ dt: Double, moving: Bool, running: Bool, safe: Bool) {
        guard phase == .closing || phase == .night else { return }
        elapsed += dt
        if phase == .closing && elapsed >= difficulty.closingDuration { phase = .night; suspicion = 0 }
        if phase == .night { nightTime += dt; poweredFor = max(0,poweredFor-dt) }
        if flashlight && !hidden { battery = max(0,battery-Float(dt)*difficulty.batteryDrain) }
        if battery <= 0 { flashlight = false }
        stamina = min(100,max(0,stamina + Float(dt)*(running && moving ? -22 : 13)))
        if safe && phase == .night { safeRoomCharge = max(0,safeRoomCharge-dt) }
    }
    mutating func reloadBattery() -> Bool {
        guard batteries > 0 && battery < 95 else { return false }
        batteries -= 1; battery = 100; return true
    }
    mutating func repairPower() -> Bool {
        guard phase == .night && fuses > 0 else { return false }
        fuses -= 1; poweredFor = 45; return true
    }
    mutating func spendCoin() -> Bool {
        guard coins > 0 else { return false }; coins -= 1; return true
    }
}

struct ModelPlacement:Decodable {
    let model:String;let x:Float;let z:Float;let y:Float;let height:Float;let yaw:Float;let stretch:Float
    let collision:Bool;let w:Float;let d:Float
}
enum MallDecor {
    static let placements:[ModelPlacement] = {
        guard let url=Bundle.main.url(forResource:"mall-dressing",withExtension:"json",subdirectory:"GameAssets"),
              let data=try? Data(contentsOf:url),let items=try? JSONDecoder().decode([ModelPlacement].self,from:data) else {return []}
        return items
    }()
}

struct MallLayout {
    let areas: [Block] = [Block(x:0,z:0,w:8,d:76),Block(x:0,z:0,w:52,d:10),
        Block(x:-14,z:-22,w:20,d:24),Block(x:14,z:-22,w:20,d:24),
        Block(x:-14,z:22,w:20,d:24),Block(x:14,z:22,w:20,d:24),
        Block(x:-20,z:2,w:12,d:12),Block(x:20,z:0,w:12,d:10)]
    var obstacles: [Block] = []
    private(set) var walls:[Block]=[]
    init() {
        // Shopfronts leave two-metre-wide entrances at z = -20 and +20.
        for side: Float in [-1,1] {
            for z: Float in [-30,-12,12,30] { obstacles.append(Block(x:side*4,z:z,w:0.3,d:8)) }
            for z: Float in [-25,25] { if side < 0 && z < 0 {obstacles.append(Block(x:side*14,z:z,w:0.3,d:5))} }
            for z: Float in [-16,16] { obstacles.append(Block(x:side*16,z:z,w:8,d:1.2)) }
        }
        for z: Float in [-34,-10,10,34] {
            obstacles.append(Block(x:-14,z:z,w:20,d:0.3));obstacles.append(Block(x:14,z:z,w:20,d:0.3))
        }
        for x: Float in [-24,24] { for z: Float in [-22,22] { obstacles.append(Block(x:x,z:z,w:0.3,d:24)) } }
        // Furniture collision uses the same downloaded model placements as rendering.
        obstacles = obstacles.filter {$0.w < 0.4 || $0.d < 0.4}
        walls=obstacles
        obstacles += [Block(x:-1.8,z:0,w:1.6,d:4),Block(x:1.8,z:0,w:1.6,d:4)]
        for item in MallDecor.placements where item.collision {obstacles.append(Block(x:item.x,z:item.z,w:item.w,d:item.d))}
        for z in stride(from:-34,through:34,by:8) {for x:Float in [-3.7,3.7] {obstacles.append(Block(x:x,z:Float(z),w:0.7,d:0.7))}}

    }
    func walkable(_ p: Point, radius: Float = 0.28) -> Bool {
        areas.contains { $0.contains(p,margin:0.02) } && !obstacles.contains { $0.contains(p,margin:radius) }
    }
    func clearLine(_ a: Point, _ b: Point) -> Bool {
        let distance = a.distance(b)
        let count = max(1,Int(distance/0.35))
        for i in 0...count { if !walkable(a+(b-a)*(Float(i)/Float(count)),radius:0.03) { return false } }
        return true
    }
    func move(_ p: Point, delta: Point) -> Point {
        var result=p
        let steps=max(1,Int(delta.length/0.15)+1)
        let step=delta*(1/Float(steps))
        for _ in 0..<steps {
            let x=Point(x:result.x+step.x,z:result.z)
            if walkable(x) { result=x }
            let z=Point(x:result.x,z:result.z+step.z)
            if walkable(z) { result=z }
        }
        return result
    }
    // Fixed grid keeps enemy navigation deterministic and walls authoritative.
    func route(from: Point, to: Point) -> [Point] {
        struct Cell: Hashable { let x: Int; let z: Int; var point: Point { Point(x:Float(x)*2,z:Float(z)*2) } }
        func nearest(_ p: Point) -> Cell? {
            let cx=Int((p.x/2).rounded()),cz=Int((p.z/2).rounded())
            var choices:[Cell]=[]
            for x in cx-2...cx+2 { for z in cz-2...cz+2 { let c=Cell(x:x,z:z);if walkable(c.point) && clearLine(p,c.point) { choices.append(c) } } }
            return choices.min { $0.point.distance(p) < $1.point.distance(p) }
        }
        guard let start=nearest(from),let end=nearest(to) else { return [] }
        var queue=[start],head=0,seen:Set<Cell>=[start],parent:[Cell:Cell]=[:]
        while head < queue.count && queue.count < 2000 {
            let c=queue[head];head += 1
            if c==end {
                var path=[c.point],cursor=c
                while let p=parent[cursor] { path.append(p.point);cursor=p }
                return Array(path.reversed().dropFirst())+[to]
            }
            for (dx,dz) in [(1,0),(-1,0),(0,1),(0,-1)] {
                let n=Cell(x:c.x+dx,z:c.z+dz)
                if abs(n.x)>14 || abs(n.z)>19 || seen.contains(n) || !walkable(n.point) || !clearLine(c.point,n.point) { continue }
                seen.insert(n);parent[n]=c;queue.append(n)
            }
        }
        return []
    }
}
