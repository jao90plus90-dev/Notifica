import SceneKit
import UIKit

extension MallScene {
    @discardableResult func placeModel(_ name:String,_ x:Float,_ z:Float,height:Float,yaw:Float=0,y:Float=0) -> SCNNode? {
        guard let n=models.model(name,height:height,position:SCNVector3(x,y,z),yaw:yaw) else {return nil}
        scene.rootNode.addChildNode(n);return n
    }
    func dressMall() {
        for p in MallDecor.placements {
            if let node=placeModel(p.model,p.x,p.z,height:p.height,yaw:p.yaw,y:p.y) {node.scale.x *= p.stretch}
        }
        sign("AURORA  /  GALERIA CENTRAL",at:SCNVector3(0,3.8,27),width:6,height:0.55,color:UIColor(red:0.09,green:0.12,blue:0.13,alpha:1),glow:true)
    }
    func addAtriumDetails() {
        let stone=mat("warmStone",UIColor(red:0.28,green:0.26,blue:0.23,alpha:1),rough:0.55)
        let bronze=mat("bronzeTrim",UIColor(red:0.32,green:0.25,blue:0.13,alpha:1),metal:0.75,rough:0.3)
        for side:Float in [-1,1] {
            // Shopfront cornices and a recessed marble base, instead of blank concrete.
            for z:Float in [-22,22] {
                box(0.45,0.2,24,bronze,at:SCNVector3(side*4,3.65,z))

            }
            for z:Float in [-30,-12,12,30] {box(0.4,0.34,8,stone,at:SCNVector3(side*4,0.17,z))}
            for z in stride(from:-34,through:34,by:8) {
                box(0.7,4.6,0.7,stone,at:SCNVector3(side*3.7,2.3,Float(z)))
                box(0.78,0.22,0.78,bronze,at:SCNVector3(side*3.7,0.18,Float(z)))
            }
        }
        let glass=mat("skylight",UIColor(red:0.11,green:0.18,blue:0.24,alpha:1),metal:0.45,rough:0.18)
        glass.emission.contents=UIColor(red:0.08,green:0.12,blue:0.17,alpha:1);glass.emission.intensity=0.15
        box(7.6,0.08,16,glass,at:SCNVector3(0,4.62,0))
        for z in stride(from:-8,through:8,by:2) {box(8,0.16,0.09,bronze,at:SCNVector3(0,4.45,Float(z)))}
        for x:Float in [-3.9,0,3.9] {box(0.08,0.15,16,bronze,at:SCNVector3(x,4.47,0))}
        // Glass-and-metal balustrades visually finish the existing escalators.
        let rail=mat("railGlass",UIColor(red:0.25,green:0.38,blue:0.4,alpha:1),metal:0.2,rough:0.15)
        rail.transparency=0.28;rail.isDoubleSided=true
        for x:Float in [-2.65,-0.95,0.95,2.65] {
            let panel=box(0.035,0.7,4,rail,at:SCNVector3(x,1.02,0));panel.eulerAngles.x = -0.3
            let top=box(0.075,0.08,4.1,bronze,at:SCNVector3(x,1.4,0));top.eulerAngles.x = -0.3
        }
    }
}
