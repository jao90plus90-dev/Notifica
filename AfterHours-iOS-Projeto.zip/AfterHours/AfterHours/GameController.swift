import UIKit
import SceneKit

final class GameController:UIViewController {
    let mall=MallScene()
    let sceneView=SCNView()
    var state=RunState()
    let audio=HorrorAudio()
    private let stick=StickView(),look=LookView(),tape=TapeOverlay()
    private let top=UILabel(),objective=UILabel(),stats=UILabel(),prompt=UILabel(),notice=UILabel(),crosshair=UILabel()
    private let interact=UIButton(type:.system),crouch=UIButton(type:.system),run=UIButton(type:.system),light=UIButton(type:.system),coin=UIButton(type:.system),battery=UIButton(type:.system),mapButton=UIButton(type:.system),pause=UIButton(type:.system)
    private let menu=UIView(),menuTitle=UILabel(),menuText=UILabel(),menuTag=UILabel()
    private let playButton=UIButton(type:.system),difficultyButton=UIButton(type:.system),resumeButton=UIButton(type:.system),vhsButton=UIButton(type:.system)
    private let mapView=MapView(),cameraBack=UIButton(type:.system)
    private var displayLink:CADisplayLink?,lastFrame:CFTimeInterval=0
    private var playing=false,paused=false,cameraMode=false,mapOpen=false,running=false
    private var yaw:Float = .pi,pitch:Float=0,elapsed:Double=0,noticeUntil:Double=0,footstep:Double=0,aiTimer:Double=0
    private var lastPhase:NightPhase = .closing,lastBlackout=false
    private var guardRoutes:[[Point]]=[[],[]],guardPatrol:[Int]=[0,0]
    private var monsterRoute:[Point]=[],monsterGoal=Point(x:-18,z:22),monsterAwareness:Double=0,distractionUntil:Double=0
    private var soundPoint:Point?,noiseCooldown:Double=0,monsterPatrol=0
    private var hidingID:String?,hiddenWitnessed=false,lastInteract:Double = -10
    private var savedBest:Int {get {UserDefaults.standard.integer(forKey:"afterhours.best") }set {UserDefaults.standard.set(newValue,forKey:"afterhours.best")}}
    private let patrols:[[Point]]=[
        [Point(x:0,z:-6),Point(x:0,z:-27),Point(x:18,z:-20),Point(x:0,z:-20)],
        [Point(x:-18,z:20),Point(x:0,z:20),Point(x:18,z:20),Point(x:0,z:8),Point(x:-19,z:1)]]
    private let monsterPatrols=[Point(x:-18,z:20),Point(x:0,z:28),Point(x:18,z:20),Point(x:0,z:0),Point(x:18,z:-20),Point(x:0,z:-28),Point(x:-18,z:-20)]
    var playerPoint:Point {Point(x:mall.player.position.x,z:mall.player.position.z)}

    override var prefersStatusBarHidden:Bool {true}
    override var prefersHomeIndicatorAutoHidden:Bool {true}
    override var supportedInterfaceOrientations:UIInterfaceOrientationMask {.landscape}
    override func viewDidLoad() {
        super.viewDidLoad();view.backgroundColor = .black
        sceneView.scene=mall.scene;sceneView.pointOfView=mall.camera
        sceneView.backgroundColor = .black;sceneView.preferredFramesPerSecond=30;sceneView.antialiasingMode = .multisampling2X
        sceneView.isPlaying=true;sceneView.autoenablesDefaultLighting=false;view.addSubview(sceneView)
        look.isMultipleTouchEnabled=false;view.addSubview(look)
        look.onLook={ [weak self] delta in
            guard let s=self,s.playing,!s.paused,!s.cameraMode,!s.mapOpen else {return}
            s.yaw -= Float(delta.x)*0.004;s.pitch=max(-1.1,min(1.1,s.pitch-Float(delta.y)*0.004))
        }
        buildHUD();buildMenu();view.addSubview(tape);tape.isUserInteractionEnabled=false
        NotificationCenter.default.addObserver(self,selector:#selector(background),name:UIApplication.willResignActiveNotification,object:nil)
        showMenu(initial:true)
        displayLink=CADisplayLink(target:self,selector:#selector(frame(_:)));displayLink?.add(to:.main,forMode:.common)
        let args=ProcessInfo.processInfo.arguments
        if args.contains("--preview-night") {startGame();state.phase = .night;state.nightTime=115;mall.player.position=SCNVector3(0,0,-15);yaw = .pi;state.battery=72}
        if args.contains("--preview-closing") {startGame();mall.player.position=SCNVector3(0,0,-27);yaw = .pi}
        if args.contains("--preview-monster") {startGame();state.phase = .night;state.nightTime=115;mall.player.position=SCNVector3(0,0,20);mall.monster.position=SCNVector3(0,0,25);yaw = .pi;monsterAwareness=0;paused=true;refreshHUD()}
    }
    deinit {displayLink?.invalidate();NotificationCenter.default.removeObserver(self)}
    private func label(_ label:UILabel,font:CGFloat,color:UIColor = .white) {
        label.font=UIFont.monospacedSystemFont(ofSize:font,weight:.medium);label.textColor=color;label.numberOfLines=0
        label.layer.shadowColor=UIColor.black.cgColor;label.layer.shadowOpacity=0.9;label.layer.shadowRadius=4;label.layer.shadowOffset = .zero;view.addSubview(label)
    }
    private func button(_ b:UIButton,_ text:String,_ action:Selector) {
        b.setTitle(text,for:.normal);b.setTitleColor(UIColor(white:0.9,alpha:1),for:.normal);b.titleLabel?.font=UIFont.monospacedSystemFont(ofSize:11,weight:.semibold)
        b.backgroundColor=UIColor(white:0.04,alpha:0.68);b.layer.cornerRadius=12;b.layer.borderWidth=1;b.layer.borderColor=UIColor.white.withAlphaComponent(0.22).cgColor
        b.addTarget(self,action:action,for:.touchUpInside);view.addSubview(b)
    }
    private func buildHUD() {
        label(top,font:12);label(objective,font:13);label(stats,font:11,color:UIColor(white:0.75,alpha:1));label(prompt,font:12);label(notice,font:13,color:UIColor(red:0.94,green:0.79,blue:0.57,alpha:1));label(crosshair,font:18)
        crosshair.text="·";crosshair.textAlignment = .center;notice.textAlignment = .center;prompt.textAlignment = .center
        view.addSubview(stick)
        button(interact,"INTERAGIR",#selector(interactTap));button(crouch,"AGACHAR",#selector(crouchTap));button(run,"CORRER",#selector(runToggle));button(light,"LUZ",#selector(lightTap));button(coin,"MOEDA",#selector(coinTap));button(battery,"PILHA",#selector(batteryTap));button(mapButton,"MAPA",#selector(mapTap));button(pause,"Ⅱ",#selector(pauseTap))
        run.removeTarget(self,action:#selector(runToggle),for:.touchUpInside)
        run.addTarget(self,action:#selector(runDown),for:.touchDown)
        for event in [UIControl.Event.touchUpInside,.touchUpOutside,.touchCancel] {run.addTarget(self,action:#selector(runUp),for:event)}
        view.addSubview(mapView);mapView.isHidden=true
        button(cameraBack,"SAIR DAS CÂMERAS",#selector(closeCamera));cameraBack.isHidden=true
    }
    private func buildMenu() {
        menu.backgroundColor=UIColor(red:0.015,green:0.023,blue:0.026,alpha:0.94);view.addSubview(menu)
        menuTag.text="SHOPPING AURORA     /     FITA 001";menuTag.font=UIFont.monospacedSystemFont(ofSize:11,weight:.medium);menuTag.textColor=UIColor(red:0.7,green:0.76,blue:0.73,alpha:1);menu.addSubview(menuTag)
        menuTitle.text="AFTER\nHOURS";menuTitle.numberOfLines=2;menuTitle.font=UIFont.systemFont(ofSize:54,weight:.black);menuTitle.textColor=UIColor(red:0.93,green:0.87,blue:0.74,alpha:1);menu.addSubview(menuTitle)
        menuText.numberOfLines=0;menuText.font=UIFont.systemFont(ofSize:14);menuText.textColor=UIColor(white:0.73,alpha:1);menu.addSubview(menuText)
        for (b,text,sel) in [(playButton,"ENTRAR NO SHOPPING",#selector(playTap)),(difficultyButton,"NORMAL",#selector(difficultyTap)),(resumeButton,"CONTINUAR",#selector(resumeTap)),(vhsButton,"VHS: LIGADO",#selector(vhsTap))] {
            b.setTitle(text,for:.normal);b.titleLabel?.font=UIFont.monospacedSystemFont(ofSize:13,weight:.semibold);b.setTitleColor(.white,for:.normal);b.layer.cornerRadius=8;b.layer.borderWidth=1;b.layer.borderColor=UIColor.white.withAlphaComponent(0.25).cgColor;b.addTarget(self,action:sel,for:.touchUpInside);menu.addSubview(b)
        }
        playButton.backgroundColor=UIColor(red:0.31,green:0.19,blue:0.12,alpha:1)
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews();let b=view.bounds,s=view.safeAreaInsets,l=max(30,s.left+12),r=max(30,s.right+12),w=b.width
        sceneView.frame=b;look.frame=CGRect(x:w*0.34,y:0,width:w*0.66,height:b.height);tape.frame=b
        top.frame=CGRect(x:l,y:24,width:w-150,height:23);objective.frame=CGRect(x:l,y:51,width:w-2*l-100,height:43)
        stats.frame=CGRect(x:l,y:99,width:390,height:24)
        crosshair.frame=CGRect(x:w/2-10,y:b.height/2-14,width:20,height:28)
        notice.frame=CGRect(x:w*0.20,y:b.height*0.29,width:w*0.60,height:52)
        prompt.frame=CGRect(x:w*0.25,y:b.height-61,width:w*0.50,height:35)
        stick.frame=CGRect(x:l+12,y:b.height-166,width:126,height:126)
        pause.frame=CGRect(x:w-r-45,y:24,width:45,height:36)
        interact.frame=CGRect(x:w-r-112,y:b.height-161,width:112,height:55)
        crouch.frame=CGRect(x:w-r-112,y:b.height-96,width:112,height:43)
        run.frame=CGRect(x:l+151,y:b.height-95,width:82,height:43)
        let quick:[UIButton]=[light,battery,coin,mapButton]
        for (i,x) in quick.enumerated() {x.frame=CGRect(x:w-r-CGFloat(4-i)*65,y:72,width:58,height:35)}
        menu.frame=b
        let left=l+20
        menuTag.frame=CGRect(x:left,y:31,width:370,height:20)
        menuTitle.frame=CGRect(x:left,y:63,width:w*0.43,height:144)
        menuText.frame=CGRect(x:left,y:218,width:w*0.47,height:max(70,b.height-242))
        let bx=w*0.60,bw=w-bx-r-18
        playButton.frame=CGRect(x:bx,y:90,width:bw,height:52)
        difficultyButton.frame=CGRect(x:bx,y:155,width:bw,height:42)
        vhsButton.frame=CGRect(x:bx,y:209,width:bw,height:42)
        resumeButton.frame=CGRect(x:bx,y:263,width:bw,height:42)
        mapView.frame=CGRect(x:w/2-230,y:28,width:460,height:b.height-56)
        cameraBack.frame=CGRect(x:w/2-105,y:b.height-65,width:210,height:42)
    }
    private func controlsVisible(_ value:Bool) {
        for v in [stick,interact,crouch,run,light,coin,battery,mapButton,pause,top,objective,stats,prompt,crosshair] as [UIView] {v.isHidden = !value}
    }
    private func showMenu(initial:Bool=false,message:String?=nil) {
        paused=true;running=false;stick.reset();menu.isHidden=false;controlsVisible(false);mapView.isHidden=true;cameraBack.isHidden=true
        menuTitle.text=message == nil ? "AFTER\nHOURS" : state.phase == .escaped ? "VOCÊ\nESCAPOU" : state.phase == .caught ? "FIM DA\nFITA" : "EM\nPAUSA"
        menuText.text=message ?? "Lia esqueceu o celular na praça de alimentação. Você ficou para buscá-lo. O último guarda está fechando as portas.\n\nMova no círculo esquerdo. Arraste à direita para olhar. Use fones. Uma noite dura cerca de 7 minutos."
        playButton.setTitle(playing ? "RECOMEÇAR A NOITE":"ENTRAR NO SHOPPING",for:.normal)
        difficultyButton.setTitle("DIFICULDADE: \(state.difficulty.title.uppercased())",for:.normal)
        resumeButton.isHidden = !playing || state.phase == .caught || state.phase == .escaped
        audio.stop()
    }
    @objc private func playTap() {
        if playing && state.phase != .caught && state.phase != .escaped {
            let a=UIAlertController(title:"Recomeçar?",message:"O progresso desta noite será perdido.",preferredStyle:.alert)
            a.addAction(UIAlertAction(title:"Cancelar",style:.cancel));a.addAction(UIAlertAction(title:"Recomeçar",style:.destructive){[weak self] _ in self?.startGame()});present(a,animated:true)
        } else {startGame()}
    }
    func startGame() {
        let difficulty=state.difficulty;state=RunState();state.difficulty=difficulty
        playing=true;paused=false;cameraMode=false;mapOpen=false;running=false
        elapsed=0;lastFrame=0;yaw = .pi;pitch=0;aiTimer=0;footstep=0;noiseCooldown=0
        monsterAwareness=0;distractionUntil=0;soundPoint=nil;hiddenWitnessed=false;hidingID=nil;lastPhase = .closing;lastBlackout=false
        guardRoutes=[[],[]];guardPatrol=[0,0];monsterRoute=[];monsterPatrol=0
        mall.player.position=SCNVector3(0,0,-31);mall.monster.position=SCNVector3(-18,0,22)
        mall.guardNodes[0].position=SCNVector3(0,0,-8);mall.guardNodes[1].position=SCNVector3(-18,0,20)
        for i in mall.items.indices {mall.items[i].collected=false;mall.items[i].node.isHidden=false}
        sceneView.pointOfView=mall.camera;menu.isHidden=true;mapView.isHidden=true;cameraBack.isHidden=true;controlsVisible(true);stick.reset()
        audio.start();audio.play("alarm");say("21:00 • O shopping está fechando. Evite as lanternas.",seconds:6)
        refreshHUD()
    }
    @objc private func difficultyTap() {state.difficulty=Difficulty(rawValue:(state.difficulty.rawValue+1)%3)!;difficultyButton.setTitle("DIFICULDADE: \(state.difficulty.title.uppercased())",for:.normal)}
    @objc private func vhsTap() {tape.grain=tape.grain>0 ? 0:0.08;tape.setNeedsDisplay();vhsButton.setTitle(tape.grain>0 ? "VHS: LIGADO":"VHS: DESLIGADO",for:.normal)}
    @objc private func resumeTap() {paused=false;lastFrame=0;menu.isHidden=true;controlsVisible(true);mapView.isHidden = !mapOpen;cameraBack.isHidden = !cameraMode;audio.start()}
    @objc private func pauseTap() {showMenu(message:"A fita está pausada. Você pode continuar ou recomeçar a noite.")}
    @objc private func background() {guard playing,!paused else {return};pauseTap()}
    @objc private func runDown() {running=true}
    @objc private func runUp() {running=false}
    @objc private func runToggle() {}
    @objc private func crouchTap() {state.crouched.toggle();crouch.setTitle(state.crouched ? "LEVANTAR":"AGACHAR",for:.normal)}
    @objc private func lightTap() {if state.battery>0 {state.flashlight.toggle()}else{say("Lanterna sem carga. Use PILHA.")}}
    @objc private func batteryTap() {say(state.reloadBattery() ? "Bateria substituída.":"Sem bateria reserva ou carga ainda suficiente.");refreshHUD()}
    @objc private func coinTap() {
        guard !state.hidden,!cameraMode else {return}
        guard state.spendCoin() else {say("Você não tem moedas.");return}
        var target=playerPoint;let direction=Point(x:-sin(yaw),z:-cos(yaw))
        for _ in 0..<30 {let next=target+direction*0.3;if mall.layout.walkable(next) {target=next}else{break}}
        makeNoise(target,lasting:12);audio.play("metal");say("Moeda lançada. O som desviou a atenção.");refreshHUD()
    }
    @objc private func mapTap() {
        guard state.map else {say("Encontre o mapa na entrada da loja de roupas.");return}
        guard !cameraMode else {return};mapOpen.toggle();mapView.isHidden = !mapOpen;stick.reset();updateMap();interact.setTitle(mapOpen ? "FECHAR MAPA":"INTERAGIR",for:.normal)
    }
    @objc private func closeCamera() {cameraMode=false;sceneView.pointOfView=mall.camera;cameraBack.isHidden=true;controlsVisible(true);say("Você saiu das câmeras.")}
    private func nearestItem() -> Int? {
        mall.items.indices.filter{!mall.items[$0].collected && mall.items[$0].point.distance(playerPoint)<2.35}.min{mall.items[$0].point.distance(playerPoint)<mall.items[$1].point.distance(playerPoint)}
    }
    @objc private func interactTap() {
        guard playing,!paused,elapsed-lastInteract>0.3 else {return};lastInteract=elapsed
        if mapOpen {mapTap();return}
        if state.hidden {state.hidden=false;hidingID=nil;hiddenWitnessed=false;say("Você saiu do esconderijo.");refreshHUD();return}
        guard let i=nearestItem() else {say("Aproxime-se de um objeto ou esconderijo.");return}
        let item=mall.items[i]
        switch item.kind {
        case .locker,.counter,.vent:
            state.hidden=true;hidingID=item.id;state.flashlight=false
            hiddenWitnessed=state.phase == .night && playerPoint.distance(point(mall.monster))<8 && mall.layout.clearLine(point(mall.monster),playerPoint)
            say(hiddenWitnessed ? "Ele viu você entrar. Saia e procure outro lugar!":"Escondido. A lanterna foi desligada.")
        case .camera:
            if state.phase != .night {say("A central está ocupada pelos seguranças.");return}
            guard state.safeRoomCharge>0 else {say("Sem energia na central. A porta não protege mais.");return}
            cameraMode=true;sceneView.pointOfView=mall.securityCamera;cameraBack.isHidden=false;controlsVisible(false);top.isHidden=false;stats.isHidden=false;say("CFTV • A energia da sala é limitada.")
        case .generator:
            if state.repairPower() {audio.play("alarm");say("Energia restaurada por 45 segundos.")}else{say(state.phase == .closing ? "O quadro ainda está ligado.":"Encontre um fusível na loja de brinquedos ou no fliperama.")}
        case .exit:
            if state.canEscape {finish(won:true,reason:"06:00. As docas abriram. O celular da Lia está com você. Mas uma última foto mostra alguém atrás de você.")}
            else if !state.phone {say("Você não vai embora sem o celular da Lia.")}
            else if !state.key {say("Falta a chave das docas, na loja de roupas.")}
            else if !state.radio {say("O painel pede uma senha. Encontre o rádio no depósito.")}
            else {say("Senha 0610 aceita. A trava só libera às 06:00.")}
        case .arcade:
            guard state.spendCoin() else {say("O brinquedo precisa de uma moeda.");return}
            audio.play("toy");makeNoise(item.point,lasting:18);say("O brinquedo começou a tocar. Afaste-se.")
        default:
            switch item.kind {
            case .phone:state.phone=true;say("Celular recuperado. A última foto é de um guarda no depósito…",seconds:7)
            case .key:state.key=true;say("Chave das docas encontrada.")
            case .radio:state.radio=true;audio.play("radio");say("RÁDIO: «Senha 0610… portão às seis… não siga o som dele.»",seconds:8)
            case .map:state.map=true;say("Mapa encontrado. Toque em MAPA para consultar.")
            case .battery:state.batteries += 1;say("Bateria reserva coletada.")
            case .coin:state.coins += 2;say("Duas moedas coletadas.")
            case .fuse:state.fuses += 1;say("Fusível encontrado. Use-o no quadro do depósito.")
            default:break
            }
            mall.items[i].collected=true;mall.items[i].node.isHidden=true;audio.play("pickup",volume:0.3)
        }
        refreshHUD()
    }
    private func say(_ text:String,seconds:Double=4) {notice.text=text;noticeUntil=elapsed+seconds;notice.isHidden=false}
    private func point(_ node:SCNNode)->Point {Point(x:node.position.x,z:node.position.z)}
    private func makeNoise(_ p:Point,lasting:Double=7) {soundPoint=p;distractionUntil=elapsed+lasting;monsterAwareness=lasting;monsterGoal=p}
    @objc private func frame(_ link:CADisplayLink) {
        let dt=min(0.05,lastFrame==0 ? 1/30:link.timestamp-lastFrame);lastFrame=link.timestamp
        guard playing,!paused else {mall.applyLighting(state:state,time:elapsed);return}
        elapsed += dt
        let moving=abs(stick.value.x)+abs(stick.value.y)>0.12 && !state.hidden && !cameraMode && !mapOpen
        let sprint=running && state.stamina>8 && !state.crouched && moving
        let safe=playerPoint.x < -14 && abs(playerPoint.z)<6
        state.tick(dt,moving:moving,running:sprint,safe:safe)
        if state.phase != lastPhase {
            if state.phase == .night {audio.play("alarm");say("00:00 • O último guarda saiu. O celular está na praça de alimentação.",seconds:7);guardRoutes=[[],[]];monsterRoute=[]}
            lastPhase=state.phase
        }
        if state.blackout != lastBlackout {
            if state.blackout {audio.play("metal");say("APAGÃO • Ele caça pelo som. Apague a luz e se esconda.",seconds:5)}else{say("A energia voltou. Aproveite para se mover.")}
            lastBlackout=state.blackout
        }
        if moving {
            let speed:Float=state.crouched ? 1.15:sprint ? 4.2:2.25
            let input=Point(x:Float(stick.value.x),z:Float(stick.value.y));let clamped=input.length>1 ? input.normalized:input
            let delta=Point(x:cos(yaw)*clamped.x+sin(yaw)*clamped.z,z:-sin(yaw)*clamped.x+cos(yaw)*clamped.z)*speed*Float(dt)
            let p=mall.layout.move(playerPoint,delta:delta);mall.player.position=SCNVector3(p.x,0,p.z)
            footstep += dt
            if footstep>(sprint ? 0.3:state.crouched ? 0.85:0.52) {audio.play("step",volume:state.crouched ? 0.05:sprint ? 0.35:0.13);footstep=0;if sprint {makeNoise(p,lasting:3)}}
            naturalTraps()
        }
        mall.player.eulerAngles.y=yaw;mall.head.eulerAngles.x=pitch
        let eye:Float=state.hidden ? 0.78:state.crouched ? 1.0:1.63
        mall.head.position.y += (eye-mall.head.position.y)*min(1,Float(dt)*10)
        if moving {mall.head.position.y += sin(Float(elapsed)*(sprint ? 13:8))*0.009}
        updateAI(dt)
        mall.applyLighting(state:state,time:elapsed)
        if safe && state.safeRoomCharge<=0 && cameraMode {closeCamera();say("A central ficou sem energia. A porta destrancou!",seconds:6)}
        if cameraMode {mall.securityCamera.eulerAngles.y = Float(Int(elapsed/8)%4)*Float.pi/2}
        if noticeUntil<elapsed {notice.isHidden=true}
        if Int(elapsed*8) != Int((elapsed-dt)*8) {refreshHUD();tape.setNeedsDisplay();if mapOpen {updateMap()}}
        let threat=state.phase == .night ? max(0,1-playerPoint.distance(point(mall.monster))/16):Float(state.suspicion)
        audio.tension(threat)
    }
    private func naturalTraps() {
        guard elapsed>noiseCooldown,!state.crouched else {return}
        let p=playerPoint
        if p.distance(Point(x:10,z:-20))<1.2 {audio.play("toy");makeNoise(p,lasting:10);say("Você pisou em um brinquedo. Eles ouviram!");noiseCooldown=elapsed+15}
        if p.distance(Point(x:15,z:18))<1.3 {audio.play("metal");makeNoise(p,lasting:10);say("Uma bandeja caiu no chão. Saia daí!");noiseCooldown=elapsed+15}
    }
    private func follow(_ node:SCNNode,path:inout [Point],speed:Float,dt:Double) {
        guard let target=path.first else {return}
        let p=point(node),delta=target-p
        if delta.length<0.35 {path.removeFirst();return}
        let next=mall.layout.move(p,delta:delta.normalized*min(delta.length,speed*Float(dt)))
        if next.distance(p)<0.001 {path=[];return}
        node.position=SCNVector3(next.x,0,next.z);node.eulerAngles.y=atan2(-delta.x,-delta.z)
    }
    private func updateAI(_ dt:Double) {
        aiTimer -= dt;let replan=aiTimer<=0;if replan {aiTimer=0.8}
        if state.phase == .closing {
            var visible=false
            for i in 0..<mall.guardNodes.count {
                let node=mall.guardNodes[i],p=point(node),offset=playerPoint-p,d=offset.length
                let facing=Point(x:-sin(node.eulerAngles.y),z:-cos(node.eulerAngles.y))
                let dot=facing.x*offset.normalized.x+facing.z*offset.normalized.z
                let seen = !state.hidden && d<(state.crouched ? 8:13) && (dot>0.6 || d<2.4) && mall.layout.clearLine(p,playerPoint)
                visible = visible || seen
                if replan {
                    var target=patrols[i][guardPatrol[i]]
                    if seen {target=playerPoint}
                    else if elapsed<distractionUntil,let sound=soundPoint {target=sound}
                    else if p.distance(target)<2 {guardPatrol[i]=(guardPatrol[i]+1)%patrols[i].count;target=patrols[i][guardPatrol[i]]}
                    guardRoutes[i]=mall.layout.route(from:p,to:target)
                }
                var path=guardRoutes[i];follow(node,path:&path,speed:seen ? 2.8:1.25,dt:dt);guardRoutes[i]=path
                if seen && d<1.1 {finish(won:false,reason:"O segurança encontrou você e o acompanhou até a saída. A noite terminou antes de começar.");return}
            }
            state.suspicion=max(0,min(1,state.suspicion+dt*(visible ? state.difficulty.detectionRate:-0.32)))
            if state.suspicion>=1 {finish(won:false,reason:"Você ficou tempo demais na luz da lanterna. O segurança viu seu rosto e expulsou você do shopping.")}
        } else if state.phase == .night {
            let p=point(mall.monster),d=playerPoint.distance(p)
            let protected=playerPoint.x < -14 && abs(playerPoint.z)<6 && state.safeRoomCharge>0
            let visible = !state.hidden && !protected && d<(state.flashlight ? 15:state.blackout ? 7:5) && mall.layout.clearLine(p,playerPoint)
            let heard = !state.hidden && !protected && running && d<17
            if visible || heard || (state.hidden && hiddenWitnessed) {monsterAwareness=8;monsterGoal=playerPoint}
            else {monsterAwareness=max(0,monsterAwareness-dt)}
            if replan {
                if elapsed<distractionUntil,let sound=soundPoint,!visible {monsterGoal=sound}
                else if monsterAwareness<=0 {
                    if p.distance(monsterPatrols[monsterPatrol])<3 {monsterPatrol=(monsterPatrol+1)%monsterPatrols.count}
                    monsterGoal=monsterPatrols[monsterPatrol]
                }
                monsterRoute=mall.layout.route(from:p,to:monsterGoal)
            }
            let speed=state.difficulty.enemySpeed*(state.blackout ? 1.3:0.7)*(monsterAwareness>0 ? 1.15:0.65)
            follow(mall.monster,path:&monsterRoute,speed:speed,dt:dt)
            mall.monster.eulerAngles.z=sin(Float(elapsed)*7)*0.035
            if d<1.15 && !protected && (!state.hidden || hiddenWitnessed) {
                finish(won:false,reason:state.hidden ? "O mascote viu você entrar no esconderijo. Da próxima vez, quebre a linha de visão antes de se esconder.":"O mascote encontrou você. Ande agachado, apague a lanterna e use moedas para desviá-lo.")
            }
        }
    }
    private func refreshHUD() {
        guard playing else {return}
        let rec=Int(elapsed)%2==0 ? "● REC":"  REC"
        top.text=String(format:"%@     %@     %02d:%02d",rec,state.phase == .closing ? "FECHAMENTO":"DEPOIS DO EXPEDIENTE",state.hour,state.minute)
        if state.phase == .closing {objective.text="Não seja visto. Espere os seguranças saírem."}
        else if !state.phone {objective.text="01 / Recupere o celular da Lia • praça de alimentação"}
        else if !state.key {objective.text="02 / Encontre a chave das docas • loja de roupas"}
        else if !state.radio {objective.text="03 / Procure o rádio do vigilante • depósito"}
        else {objective.text=state.canEscape ? "04 / 06:00 • Vá às portas de carga. Saia agora!":"04 / Sobreviva até as 06:00 e saia pelas docas • senha 0610"}
        stats.text=String(format:"LUZ %03d%%   FÔLEGO %03d%%   MOEDAS %d   PILHAS %d   FUSÍVEIS %d",Int(state.battery),Int(state.stamina),state.coins,state.batteries,state.fuses)
        if cameraMode {top.text="● CFTV / CÂMERA \(Int(elapsed/8)%4+1)";stats.text="ENERGIA DA CENTRAL: \(Int(state.safeRoomCharge)) s"}
        if state.hidden {prompt.text=hiddenWitnessed ? "ELE VIU VOCÊ • SAIA DAÍ":"ESCONDIDO • Toque em SAIR para levantar";interact.setTitle("SAIR",for:.normal)}
        else if let i=nearestItem() {prompt.text=mall.items[i].title;interact.setTitle(mall.items[i].hiding ? "ESCONDER":"INTERAGIR",for:.normal)}
        else {prompt.text=state.suspicion>0.05 ? "DETECÇÃO \(Int(state.suspicion*100))% • SAIA DA LUZ":state.blackout ? "APAGÃO • O som entrega sua posição":"";interact.setTitle(mapOpen ? "FECHAR MAPA":"INTERAGIR",for:.normal)}
        if state.suspicion>0.05 {prompt.textColor = .systemOrange}else{prompt.textColor = .white}
        light.setTitle(state.flashlight ? "LUZ ON":"LUZ OFF",for:.normal)
        crouch.setTitle(state.crouched ? "LEVANTAR":"AGACHAR",for:.normal)
    }
    private func updateMap() {
        mapView.position=playerPoint
        mapView.targets=[("MODA",Point(x:-20,z:-24)),("BRINQUEDOS",Point(x:7,z:-24)),("ARCADE",Point(x:-20,z:24)),("ALIMENTAÇÃO",Point(x:7,z:24)),("CFTV",Point(x:-23,z:0)),("DEPÓSITO",Point(x:15,z:0)),("DOCAS",Point(x:1,z:35))]
        mapView.setNeedsDisplay()
    }
    private func finish(won:Bool,reason:String) {
        guard state.phase == .closing || state.phase == .night else {return}
        state.phase=won ? .escaped:.caught;running=false
        savedBest=max(savedBest,state.hour)
        audio.play(won ? "pickup":"scare",volume:0.9)
        if !won {
            let flash=UIView(frame:view.bounds);flash.backgroundColor=UIColor.red.withAlphaComponent(0.28);flash.isUserInteractionEnabled=false;view.addSubview(flash);UIView.animate(withDuration:0.6,animations:{flash.alpha=0}){_ in flash.removeFromSuperview()}
            if let p=mall.monster.presentation.parent,p === mall.scene.rootNode,state.nightTime>0 {
                let q=point(mall.monster);mall.player.eulerAngles.y=atan2(-(q.x-playerPoint.x),-(q.z-playerPoint.z))
            }
        }
        DispatchQueue.main.asyncAfter(deadline:.now()+0.7){[weak self] in self?.showMenu(message:reason)}
    }
    func capturePreview(_ mode:String) -> UIImage {
        if mode == "menu" { showMenu(initial:true) }
        else {
            startGame()
            if mode != "closing" {state.phase = .night;state.nightTime=115;state.battery=72;mall.player.position=SCNVector3(0,0,-15)}
            if mode == "monster" {mall.player.position=SCNVector3(0,0,20);mall.monster.position=SCNVector3(0,0,25)}
            paused=true;mall.player.eulerAngles.y = .pi
            notice.isHidden=true;refreshHUD()
        }
        mall.applyLighting(state:state,time:elapsed)
        view.setNeedsLayout();view.layoutIfNeeded();tape.setNeedsDisplay();tape.layer.displayIfNeeded()
        func prepareLayers(_ node:UIView) {
            if let button=node as? UIButton {button.titleLabel?.text=button.title(for:.normal)}
            node.setNeedsLayout();node.layoutIfNeeded();node.layer.displayIfNeeded()
            for child in node.subviews {prepareLayers(child)}
        }
        prepareLayers(view)
        let image=sceneView.snapshot()
        let format=UIGraphicsImageRendererFormat();format.scale=1
        return UIGraphicsImageRenderer(size:view.bounds.size,format:format).image { context in
            image.draw(in:view.bounds)
            for subview in view.subviews where subview !== sceneView && !subview.isHidden {
                context.cgContext.saveGState()
                context.cgContext.translateBy(x:subview.frame.minX,y:subview.frame.minY)
                subview.layer.render(in:context.cgContext)
                context.cgContext.restoreGState()
            }
        }
    }
}
