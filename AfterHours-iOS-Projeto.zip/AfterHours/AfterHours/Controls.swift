import UIKit

final class StickView: UIView {
    var value=CGPoint.zero
    private let knob=UIView()
    override init(frame:CGRect) {
        super.init(frame:frame);backgroundColor=UIColor.white.withAlphaComponent(0.045);layer.borderWidth=1;layer.borderColor=UIColor.white.withAlphaComponent(0.18).cgColor
        knob.backgroundColor=UIColor.white.withAlphaComponent(0.25);knob.isUserInteractionEnabled=false;addSubview(knob)
        isMultipleTouchEnabled=false;accessibilityLabel="Movimentar personagem"
    }
    required init?(coder:NSCoder) {fatalError()}
    override func layoutSubviews() {super.layoutSubviews();layer.cornerRadius=bounds.width/2;knob.bounds=CGRect(x:0,y:0,width:48,height:48);knob.layer.cornerRadius=24;knob.center=CGPoint(x:bounds.midX,y:bounds.midY)}
    private func set(_ t:UITouch) {
        let p=t.location(in:self),r=bounds.width*0.35
        let dx=p.x-bounds.midX,dy=p.y-bounds.midY,d=max(1,sqrt(dx*dx+dy*dy)/r)
        value=CGPoint(x:dx/d/r,y:dy/d/r);knob.center=CGPoint(x:bounds.midX+value.x*r,y:bounds.midY+value.y*r)
    }
    override func touchesBegan(_ t:Set<UITouch>,with e:UIEvent?) {if let t=t.first {set(t)}}
    override func touchesMoved(_ t:Set<UITouch>,with e:UIEvent?) {if let t=t.first {set(t)}}
    func reset() {value = .zero;knob.center=CGPoint(x:bounds.midX,y:bounds.midY)}
    override func touchesEnded(_ t:Set<UITouch>,with e:UIEvent?) {reset()}
    override func touchesCancelled(_ t:Set<UITouch>,with e:UIEvent?) {reset()}
}
final class LookView:UIView {
    var onLook:((CGPoint)->Void)?
    private var last:CGPoint?
    override func touchesBegan(_ t:Set<UITouch>,with e:UIEvent?) {last=t.first?.location(in:self)}
    override func touchesMoved(_ t:Set<UITouch>,with e:UIEvent?) {
        guard let p=t.first?.location(in:self),let old=last else {return};onLook?(CGPoint(x:p.x-old.x,y:p.y-old.y));last=p
    }
    override func touchesEnded(_ t:Set<UITouch>,with e:UIEvent?) {last=nil}
    override func touchesCancelled(_ t:Set<UITouch>,with e:UIEvent?) {last=nil}
}
final class TapeOverlay:UIView {
    var grain:CGFloat=0.14;var noiseSeed:UInt32=1
    override init(frame:CGRect) {super.init(frame:frame);isUserInteractionEnabled=false;isOpaque=false;backgroundColor = .clear}
    required init?(coder:NSCoder) {fatalError()}
    override func draw(_ rect:CGRect) {
        guard let c=UIGraphicsGetCurrentContext(),grain>0 else {return}
        c.setFillColor(UIColor.black.withAlphaComponent(grain*0.75).cgColor)
        var y:CGFloat=0
        while y<bounds.height {c.fill(CGRect(x:0,y:y,width:bounds.width,height:1));y += 4}
        for i in 0..<850 {
            noiseSeed = 1664525 &* noiseSeed &+ 1013904223
            let x=CGFloat(noiseSeed%10000)/10000*bounds.width
            noiseSeed = 1664525 &* noiseSeed &+ 1013904223
            let y=CGFloat(noiseSeed%10000)/10000*bounds.height
            c.setFillColor((i%2==0 ? UIColor.white:UIColor.black).withAlphaComponent(grain).cgColor)
            c.fill(CGRect(x:x,y:y,width:2,height:1))
        }
        let p=UIBezierPath(roundedRect:bounds.insetBy(dx:18,dy:18),cornerRadius:6);UIColor.white.withAlphaComponent(0.16).setStroke();p.lineWidth=1;p.stroke()
    }
}
final class MapView:UIView {
    var position=Point(x:0,z:0)
    var targets:[(String,Point)]=[]
    override init(frame:CGRect) {super.init(frame:frame);backgroundColor=UIColor(red:0.025,green:0.045,blue:0.04,alpha:0.97);layer.cornerRadius=18;isUserInteractionEnabled=false}
    required init?(coder:NSCoder) {fatalError()}
    override func draw(_ rect:CGRect) {
        guard let c=UIGraphicsGetCurrentContext() else {return}
        let scale=min((bounds.width-60)/54,(bounds.height-65)/80)
        func xy(_ p:Point)->CGPoint {CGPoint(x:bounds.midX+CGFloat(p.x)*scale,y:bounds.midY+CGFloat(p.z)*scale)}
        UIColor(white:0.3,alpha:1).setFill()
        for a in MallLayout().areas {let p=xy(Point(x:a.x-a.w/2,z:a.z-a.d/2));c.fill(CGRect(x:p.x,y:p.y,width:CGFloat(a.w)*scale,height:CGFloat(a.d)*scale))}
        for (title,p) in targets {let q=xy(p);UIColor.systemOrange.setFill();c.fillEllipse(in:CGRect(x:q.x-3,y:q.y-3,width:6,height:6));(title as NSString).draw(at:CGPoint(x:q.x+5,y:q.y-6),withAttributes:[.font:UIFont.monospacedSystemFont(ofSize:9,weight:.medium),.foregroundColor:UIColor.white])}
        let p=xy(position);UIColor.cyan.setFill();c.fillEllipse(in:CGRect(x:p.x-5,y:p.y-5,width:10,height:10))
        ("SHOPPING AURORA  /  VOCÊ: ●" as NSString).draw(at:CGPoint(x:20,y:15),withAttributes:[.font:UIFont.monospacedSystemFont(ofSize:13,weight:.bold),.foregroundColor:UIColor.white])
    }
}
