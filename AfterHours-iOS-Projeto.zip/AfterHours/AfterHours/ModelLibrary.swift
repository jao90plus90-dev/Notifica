import SceneKit
import ModelIO
import UIKit

/// Offline OBJ assets from Kenney, with the original CC0 notices bundled.
final class ModelLibrary {
    private var cache:[String:SCNNode]=[:]
    private var assetBounds:[String:(min:SCNVector3,max:SCNVector3)]=[:]
    private(set) var loadedNames:Set<String>=[]
    let directory:URL
    init() {
        directory=Bundle.main.resourceURL!.appendingPathComponent("Resources/Models",isDirectory:true)
    }
    func model(_ name:String,height:Float,position:SCNVector3,yaw:Float=0) -> SCNNode? {
        let template:SCNNode
        if let existing=cache[name] {template=existing}
        else {
            let url=directory.appendingPathComponent(name+".obj")
            guard FileManager.default.fileExists(atPath:url.path) else {return nil}
            let asset=MDLAsset(url:url);asset.loadTextures()
            guard asset.count>0 else {return nil}
            let b=asset.boundingBox
            assetBounds[name]=(SCNVector3(b.minBounds.x,b.minBounds.y,b.minBounds.z),SCNVector3(b.maxBounds.x,b.maxBounds.y,b.maxBounds.z))
            let imported=SCNScene(mdlAsset:asset)
            let group=SCNNode()
            for child in imported.rootNode.childNodes {group.addChildNode(child.clone())}
            guard !group.childNodes.isEmpty else {return nil}
            group.enumerateChildNodes { n,_ in
                n.geometry?.materials = (n.geometry?.materials ?? []).map { material in
                    let m=material.copy() as! SCNMaterial
                    m.lightingModel = .physicallyBased;m.roughness.contents=0.72;m.metalness.contents=0.04
                    // The OBJ texture paths are relative to the bundled MTL directory.
                    if name.hasPrefix("arcade_") || name.hasPrefix("market_") {
                        let file=name.hasPrefix("arcade_") ? "arcade_colormap.png":"market_colormap.png"
                        m.diffuse.contents=UIImage(contentsOfFile:self.directory.appendingPathComponent(file).path)
                    }
                    return m
                }
            }
            cache[name]=group;template=group;loadedNames.insert(name)
        }
        let node=template.clone(),root=SCNNode()
        guard let bounds=assetBounds[name] else {return nil}
        let extent=max(0.01,bounds.max.y-bounds.min.y)
        node.position=SCNVector3(-(bounds.min.x+bounds.max.x)/2,-bounds.min.y,-(bounds.min.z+bounds.max.z)/2)
        root.addChildNode(node)
        let factor=height/extent;root.scale=SCNVector3(factor,factor,factor)
        root.position=position;root.eulerAngles.y=yaw
        return root
    }
}
