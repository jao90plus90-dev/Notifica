import AVFoundation

final class HorrorAudio {
    private let engine=AVAudioEngine()
    private let drone=AVAudioPlayerNode(),effects=AVAudioPlayerNode()
    private let format=AVAudioFormat(standardFormatWithSampleRate:22050,channels:1)!
    private var ready=false
    private var buffers:[String:AVAudioPCMBuffer]=[:]
    init() {
        try? AVAudioSession.sharedInstance().setCategory(.ambient,mode:.default,options:.mixWithOthers)
        engine.attach(drone);engine.attach(effects)
        engine.connect(drone,to:engine.mainMixerNode,format:format);engine.connect(effects,to:engine.mainMixerNode,format:format)
        buffers["drone"]=make(4,frequency:42,noise:0.08)
        buffers["step"]=make(0.12,frequency:72,noise:0.7)
        buffers["metal"]=make(0.65,frequency:730,noise:0.65)
        buffers["toy"]=make(0.45,frequency:920,noise:0.04)
        buffers["radio"]=make(1.2,frequency:160,noise:0.8)
        buffers["alarm"]=make(1.0,frequency:480,noise:0.03)
        buffers["scare"]=make(1.5,frequency:56,noise:0.95)
        buffers["pickup"]=make(0.2,frequency:640,noise:0.02)
    }
    private func make(_ duration:Double,frequency:Double,noise:Double) -> AVAudioPCMBuffer {
        let count=AVAudioFrameCount(duration*22050)
        let b=AVAudioPCMBuffer(pcmFormat:format,frameCapacity:count)!;b.frameLength=count
        let data=b.floatChannelData![0]
        var seed:UInt32=1234567
        for i in 0..<Int(count) {
            let t=Double(i)/22050
            seed = 1664525 &* seed &+ 1013904223
            let random=Double(seed)/Double(UInt32.max)*2-1
            let envelope=duration>3 ? 0.35 : min(1,t*100)*pow(max(0,1-t/duration),1.6)
            let tone=sin(2*Double.pi*frequency*t+sin(t*9)*1.7)+0.25*sin(2*Double.pi*(frequency*1.48)*t)
            data[i]=Float((tone*(1-noise)+random*noise)*envelope*0.35)
        }
        return b
    }
    func start() {
        if !engine.isRunning {try? engine.start()}
        guard engine.isRunning else {return};ready=true
        if !drone.isPlaying,let b=buffers["drone"] {drone.scheduleBuffer(b,at:nil,options:.loops,completionHandler:nil);drone.volume=0.10;drone.play()}
    }
    func play(_ key:String,volume:Float=0.6) {
        guard ready,engine.isRunning,let b=buffers[key] else {return}
        effects.volume=volume;effects.scheduleBuffer(b,at:nil,options:[],completionHandler:nil);if !effects.isPlaying {effects.play()}
    }
    func tension(_ value:Float) {drone.volume=0.08+min(1,max(0,value))*0.2}
    func stop() {drone.stop();effects.stop();engine.pause();ready=false}
}
