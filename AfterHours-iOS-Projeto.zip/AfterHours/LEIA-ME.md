# After Hours — primeira versão jogável 0.1.0

Thriller 3D em primeira pessoa para iPhone, iOS 16+, orientação horizontal, totalmente offline.

## Instalação
Importe AfterHours.ipa no SideStore ou AltStore. O pacote não vem assinado; a ferramenta de instalação faz a assinatura. Abra o jogo e vire o iPhone na horizontal. Use fones e ajuste o volume antes de começar.

## Como jogar
- Círculo esquerdo: andar. Arraste no lado direito: olhar.
- Segure CORRER para gastar fôlego. AGACHAR reduz velocidade e ruído.
- INTERAGIR perto de objetos coleta recursos, usa quadros e acessa esconderijos.
- LUZ liga/desliga a lanterna; PILHA consome uma bateria reserva.
- MOEDA arremessa uma moeda na direção da câmera e atrai inimigos pelo som.
- MAPA só funciona depois de coletar o mapa, perto da entrada da loja de roupas.
- A pausa interrompe o tempo; retornar de outro app pausa automaticamente.

## Rota
1. No fechamento, evite as lanternas e sobreviva até os guardas saírem.
2. Pegue o celular da Lia na praça de alimentação.
3. Pegue a chave na loja de roupas e o rádio no depósito.
4. Sobreviva até 06:00 e interaja com o portão das docas ao norte do mapa.

A noite tem 6 minutos na dificuldade Normal, precedidos de 65 segundos de fechamento. O relógio é acelerado. Exploração reduz a velocidade da criatura; Pesadelo aumenta a detecção e o consumo da lanterna.

Armários, balcão e tubulação escondem você. A criatura alcança esconderijos se viu você entrar. A sala de segurança só protege por 28 segundos de ocupação; o terminal alterna entre quatro câmeras. Fusíveis restauram a energia por 45 segundos. Brinquedos e bandejas fazem barulho ao passar de pé; agache para atravessar em silêncio.

## Escopo desta versão
O jogo tem começo, duas fases, objetivos, morte, vitória, menu e reinício. O shopping é um cenário compacto interligado, criado com geometria e materiais procedurais. O mascote é um modelo articulado simples, sem ativos externos; os sons também são sintetizados. A estética usa sombras, materiais metálicos, neblina, vinheta, bloom e sobreposição VHS ajustável. É uma base jogável, não o acabamento fotorrealista da imagem conceitual nem um shopping gigantesco de produção comercial.

Não há checkpoint entre sessões nesta primeira versão. O jogo funciona offline, sem anúncios, coleta de dados ou compras.

## Compilação
macOS + Xcode 16.4 ou posterior + XcodeGen. Rode `xcodegen generate`, os testes do esquema AfterHours, e `bash scripts/build-ipa.sh`. O workflow também abre a versão de simulador e captura telas reais.
