import XCTest
import UIKit
import SceneKit
@testable import AfterHours

final class GameRulesTests:XCTestCase {
    func testClosingTransitionsToNight() {
        var s=RunState();s.difficulty = .quiet
        s.tick(44,moving:false,running:false,safe:false);XCTAssertEqual(s.phase,.closing)
        s.tick(1,moving:false,running:false,safe:false);XCTAssertEqual(s.phase,.night)
    }
    func testClosingHasNoBlackouts() {var s=RunState();s.nightTime=50;XCTAssertFalse(s.blackout)}
    func testBlackoutCycleAndFuseOverride() {
        var s=RunState();s.phase = .night;s.nightTime=45;XCTAssertTrue(s.blackout)
        s.fuses=1;XCTAssertTrue(s.repairPower());XCTAssertFalse(s.blackout);XCTAssertEqual(s.fuses,0)
        s.poweredFor=0;s.nightTime=75;XCTAssertFalse(s.blackout)
    }
    func testCannotRepairWithoutFuseOrDuringClosing() {
        var s=RunState();s.fuses=1;XCTAssertFalse(s.repairPower());s.phase = .night;s.fuses=0;XCTAssertFalse(s.repairPower())
    }
    func testEscapeRequiresAllObjectivesAndSixAM() {
        var s=RunState();s.phase = .night;s.phone=true;s.key=true;s.radio=true
        s.nightTime=359;XCTAssertFalse(s.canEscape);s.nightTime=360;XCTAssertTrue(s.canEscape)
        s.phone=false;XCTAssertFalse(s.canEscape);s.phone=true;s.radio=false;XCTAssertFalse(s.canEscape)
    }
    func testBatteryAndStaminaAreClamped() {
        var s=RunState();s.battery=0.1;s.stamina=2
        s.tick(1,moving:true,running:true,safe:false)
        XCTAssertEqual(s.battery,0);XCTAssertFalse(s.flashlight);XCTAssertEqual(s.stamina,0)
        s.tick(100,moving:false,running:false,safe:false);XCTAssertEqual(s.stamina,100)
    }
    func testReloadConsumesOnlyWhenNeeded() {
        var s=RunState();XCTAssertFalse(s.reloadBattery());XCTAssertEqual(s.batteries,1)
        s.battery=10;XCTAssertTrue(s.reloadBattery());XCTAssertEqual(s.batteries,0);XCTAssertEqual(s.battery,100)
        s.battery=10;XCTAssertFalse(s.reloadBattery())
    }
    func testCoinsNeverGoNegative() {var s=RunState();XCTAssertTrue(s.spendCoin());XCTAssertTrue(s.spendCoin());XCTAssertFalse(s.spendCoin());XCTAssertEqual(s.coins,0)}
    func testSafeRoomEnergyIsFinite() {
        var s=RunState();s.phase = .night
        s.tick(20,moving:false,running:false,safe:false);XCTAssertEqual(s.safeRoomCharge,28)
        s.tick(40,moving:false,running:false,safe:true);XCTAssertEqual(s.safeRoomCharge,0)
    }
    func testHiddenPlayerDoesNotDrainFlashlight() {var s=RunState();s.hidden=true;s.tick(10,moving:false,running:false,safe:false);XCTAssertEqual(s.battery,100)}
    func testFinishedGameStopsAdvancing() {var s=RunState();s.phase = .escaped;s.tick(100,moving:false,running:false,safe:false);XCTAssertEqual(s.elapsed,0)}
    func testCollisionPreventsLeavingTheMallAndCrossingWalls() {
        let l=MallLayout();XCTAssertFalse(l.walkable(Point(x:40,z:0)));XCTAssertFalse(l.walkable(Point(x:4,z:-30)))
        let p=l.move(Point(x:2,z:-30),delta:Point(x:7,z:0));XCTAssertLessThan(p.x,3.8)
    }
    func testLineOfSightCannotCrossShopfront() {let l=MallLayout();XCTAssertFalse(l.clearLine(Point(x:0,z:-30),Point(x:10,z:-30)));XCTAssertTrue(l.clearLine(Point(x:0,z:-20),Point(x:10,z:-20)))}
    func testEveryObjectiveHasReachableRoute() {
        let l=MallLayout(),start=Point(x:0,z:-30)
        for goal in [Point(x:20,z:18),Point(x:-21,z:-18),Point(x:22,z:1),Point(x:0,z:35),Point(x:-20,z:4),Point(x:8,z:-22)] {
            XCTAssertTrue(l.walkable(goal),"Goal \(goal)")
            let path=l.route(from:start,to:goal);XCTAssertFalse(path.isEmpty,"No route to \(goal)")
            for p in path {XCTAssertTrue(l.walkable(p),"Path crosses wall: \(p)")}
        }
    }
    func testDifficultyChangesThreatWithoutChangingObjectiveDurationContract() {
        XCTAssertLessThan(Difficulty.quiet.enemySpeed,Difficulty.nightmare.enemySpeed)
        for d in Difficulty.allCases {var s=RunState();s.phase = .night;s.difficulty=d;s.nightTime=d.nightDuration;XCTAssertEqual(s.hour,6)}
    }
    @MainActor func testWorldContainsBothPhasesAndAllObjectiveObjects() {
        let world=MallScene()
        XCTAssertEqual(world.guardNodes.count,2)
        XCTAssertEqual(world.items.filter { $0.hiding }.count,5)
        XCTAssertNotNil(world.camera.camera)
        for id in ["phone","key","radio","map","generator","exit","cctv"] {
            XCTAssertNotNil(world.items.first { $0.id == id })
        }
        var state=RunState();world.applyLighting(state:state,time:0)
        XCTAssertFalse(world.guardNodes[0].isHidden);XCTAssertTrue(world.monster.isHidden)
        state.phase = .night;state.nightTime=45;world.applyLighting(state:state,time:0)
        XCTAssertTrue(world.guardNodes[0].isHidden);XCTAssertFalse(world.monster.isHidden)
        XCTAssertTrue(world.mainLights.allSatisfy { $0.intensity == 0 })
    }
    @MainActor func testPlayableSceneRendersWithTouchInterface() {
        let controller=GameController()
        controller.loadViewIfNeeded()
        controller.view.frame=CGRect(x:0,y:0,width:844,height:390)
        controller.view.setNeedsLayout();controller.view.layoutIfNeeded()
        for mode in ["menu","closing","night","monster","arcade","food"] {
            let image=controller.capturePreview(mode)
            XCTAssertGreaterThan(image.size.width,700)
            let attachment=XCTAttachment(image:image)
            attachment.name="AfterHours-"+mode
            attachment.lifetime = .keepAlways
            add(attachment)
        }
    }
    @MainActor func testRunButtonTogglesInsteadOfRequiringHold() throws {
        let controller=GameController();controller.loadViewIfNeeded();controller.startGame()
        func find(_ view:UIView) -> UIButton? {
            if let button=view as? UIButton,button.accessibilityIdentifier == "runToggle" {return button}
            for child in view.subviews {if let match=find(child) {return match}}
            return nil
        }
        let button=try XCTUnwrap(find(controller.view))
        XCTAssertFalse(button.isSelected)
        button.sendActions(for:.touchDown);XCTAssertFalse(button.isSelected)
        button.sendActions(for:.touchUpInside);XCTAssertTrue(button.isSelected)
        button.sendActions(for:.touchUpOutside);XCTAssertTrue(button.isSelected)
        button.sendActions(for:.touchUpInside);XCTAssertFalse(button.isSelected)
        let sceneTaps=controller.view.gestureRecognizers?.compactMap {$0 as? UITapGestureRecognizer} ?? []
        XCTAssertEqual(sceneTaps.count,1)
        XCTAssertFalse(sceneTaps[0].cancelsTouchesInView)
        XCTAssertFalse(controller.view.subviews.compactMap {$0 as? UIButton}.contains {$0.title(for:.normal) == "INTERAGIR"})
    }
    @MainActor func testDownloadedModelsAndSharedFurnitureCollisionsAreBundled() throws {
        XCTAssertGreaterThan(MallDecor.placements.count,80)
        let world=MallScene()
        XCTAssertGreaterThan(world.models.loadedNames.count,20)
        XCTAssertNotNil(world.models.model("arcade_claw-machine",height:2,position:SCNVector3Zero))
        let plant=try XCTUnwrap(MallDecor.placements.first {$0.model == "furniture_pottedPlant"})
        XCTAssertFalse(world.layout.walkable(Point(x:plant.x,z:plant.z)))
        let floor=try XCTUnwrap(Bundle.main.url(forResource:"floor_diff",withExtension:"jpg",subdirectory:"Resources/Textures"))
        XCTAssertGreaterThan(try Data(contentsOf:floor).count,10000)
    }
}
