#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
xcodegen generate
xcodebuild -project AfterHours.xcodeproj -scheme AfterHours -configuration Release \
  -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build/device \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY='' build
app_path='build/device/Build/Products/Release-iphoneos/AfterHours.app'
test -f "$app_path/AfterHours"
rm -rf build/ipa
mkdir -p build/ipa/Payload
cp -R "$app_path" build/ipa/Payload/AfterHours.app
rm -rf build/ipa/Payload/AfterHours.app/_CodeSignature
rm -f build/ipa/Payload/AfterHours.app/embedded.mobileprovision
rm -f build/AfterHours.ipa
(cd build/ipa && /usr/bin/zip -qry ../AfterHours.ipa Payload)
