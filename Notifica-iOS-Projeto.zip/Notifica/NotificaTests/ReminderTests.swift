import XCTest
@testable import Notifica

final class ReminderTests: XCTestCase {
    private var calendar: Calendar {
        var value = Calendar(identifier: .gregorian)
        value.timeZone = TimeZone(secondsFromGMT: 0)!
        return value
    }

    func testRejectsEmptyTitleAndPastOneShot() {
        var reminder = Reminder()
        reminder.title = " \n "
        XCTAssertThrowsError(try reminder.validate())
        reminder.title = "Água"
        reminder.date = Date(timeIntervalSince1970: 0)
        XCTAssertThrowsError(try reminder.validate())
        reminder.enabled = false
        XCTAssertNoThrow(try reminder.validate())
        reminder.enabled = true
        reminder.repeatRule = .daily
        XCTAssertNoThrow(try reminder.validate())
    }

    func testRejectsOversizedMessages() {
        var reminder = Reminder()
        reminder.title = "Lembrete"
        reminder.message = String(repeating: "a", count: 1001)
        XCTAssertThrowsError(try reminder.validate())
    }

    func testOnceUsesFullDate() {
        var reminder = Reminder()
        reminder.date = calendar.date(from: DateComponents(year: 2030, month: 4, day: 10, hour: 21, minute: 10))!
        let trigger = reminder.trigger(calendar: calendar)
        XCTAssertFalse(trigger.repeats)
        XCTAssertEqual(trigger.dateComponents.year, 2030)
        XCTAssertEqual(trigger.dateComponents.month, 4)
        XCTAssertEqual(trigger.dateComponents.day, 10)
        XCTAssertEqual(trigger.dateComponents.hour, 21)
        XCTAssertEqual(trigger.dateComponents.minute, 10)
    }

    func testDailyDoesNotKeepOriginalDate() {
        var reminder = Reminder()
        reminder.repeatRule = .daily
        let trigger = reminder.trigger(calendar: calendar)
        XCTAssertTrue(trigger.repeats)
        XCTAssertNil(trigger.dateComponents.year)
        XCTAssertNil(trigger.dateComponents.day)
        XCTAssertNil(trigger.dateComponents.weekday)
        XCTAssertNotNil(trigger.dateComponents.hour)
    }

    func testWeeklyKeepsWeekdayOnly() {
        var reminder = Reminder()
        reminder.repeatRule = .weekly
        let trigger = reminder.trigger(calendar: calendar)
        XCTAssertTrue(trigger.repeats)
        XCTAssertEqual(trigger.dateComponents.weekday, calendar.component(.weekday, from: reminder.date))
        XCTAssertNil(trigger.dateComponents.month)
        XCTAssertNil(trigger.dateComponents.day)
    }

    func testContentAndSavedDataRoundTrip() throws {
        var reminder = Reminder()
        reminder.title = "  Beber água  "
        reminder.message = "Uma pausa 💧"
        reminder.sound = false
        XCTAssertEqual(reminder.content().title, "Beber água")
        XCTAssertEqual(reminder.content().body, reminder.message)
        XCTAssertNil(reminder.content().sound)
        let data = try JSONEncoder().encode([reminder])
        XCTAssertEqual(try JSONDecoder().decode([Reminder].self, from: data), [reminder])
    }
}
