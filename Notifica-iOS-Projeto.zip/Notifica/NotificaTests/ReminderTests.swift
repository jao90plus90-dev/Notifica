import XCTest
import UIKit
import ImageIO
@testable import Notifica

final class ReminderTests: XCTestCase {
    private var calendar: Calendar {
        var value = Calendar(identifier: .gregorian)
        value.timeZone = TimeZone(secondsFromGMT: 0)!
        return value
    }

    func testRejectsEmptyTitleAndPastOneShot() {
        var reminder = Reminder()
        reminder.title = " \n "
        XCTAssertThrowsError(try reminder.validate())
        reminder.title = "Água"
        reminder.date = Date(timeIntervalSince1970: 0)
        XCTAssertThrowsError(try reminder.validate())
        reminder.enabled = false
        XCTAssertNoThrow(try reminder.validate())
        reminder.enabled = true
        reminder.repeatRule = .daily
        XCTAssertNoThrow(try reminder.validate())
    }

    func testRejectsOversizedMessages() {
        var reminder = Reminder()
        reminder.title = "Lembrete"
        reminder.message = String(repeating: "a", count: 1001)
        XCTAssertThrowsError(try reminder.validate())
    }

    func testOnceUsesFullDate() {
        var reminder = Reminder()
        reminder.date = calendar.date(from: DateComponents(year: 2030, month: 4, day: 10, hour: 21, minute: 10))!
        let trigger = reminder.trigger(calendar: calendar)
        XCTAssertFalse(trigger.repeats)
        XCTAssertEqual(trigger.dateComponents.year, 2030)
        XCTAssertEqual(trigger.dateComponents.month, 4)
        XCTAssertEqual(trigger.dateComponents.day, 10)
        XCTAssertEqual(trigger.dateComponents.hour, 21)
        XCTAssertEqual(trigger.dateComponents.minute, 10)
    }

    func testDailyDoesNotKeepOriginalDate() {
        var reminder = Reminder()
        reminder.repeatRule = .daily
        let trigger = reminder.trigger(calendar: calendar)
        XCTAssertTrue(trigger.repeats)
        XCTAssertNil(trigger.dateComponents.year)
        XCTAssertNil(trigger.dateComponents.day)
        XCTAssertNil(trigger.dateComponents.weekday)
        XCTAssertNotNil(trigger.dateComponents.hour)
    }

    func testWeeklyKeepsWeekdayOnly() {
        var reminder = Reminder()
        reminder.repeatRule = .weekly
        let trigger = reminder.trigger(calendar: calendar)
        XCTAssertTrue(trigger.repeats)
        XCTAssertEqual(trigger.dateComponents.weekday, calendar.component(.weekday, from: reminder.date))
        XCTAssertNil(trigger.dateComponents.month)
        XCTAssertNil(trigger.dateComponents.day)
    }

    func testContentAndSavedDataRoundTrip() throws {
        var reminder = Reminder()
        reminder.title = "  Beber água  "
        reminder.message = "Uma pausa 💧"
        reminder.sound = false
        XCTAssertEqual(reminder.content().title, "Beber água")
        XCTAssertEqual(reminder.content().body, reminder.message)
        XCTAssertNil(reminder.content().sound)
        let data = try JSONEncoder().encode([reminder])
        XCTAssertEqual(try JSONDecoder().decode([Reminder].self, from: data), [reminder])
    }

    private func samplePhoto() -> Data {
        UIGraphicsImageRenderer(size: CGSize(width: 1600, height: 800)).pngData { context in
            UIColor.systemPurple.setFill()
            context.fill(CGRect(x: 0, y: 0, width: 1600, height: 800))
        }
    }

    func testPhotoIsResizedAndConvertedToJPEG() throws {
        let data = try NotificationImage.normalize(samplePhoto())
        XCTAssertEqual(Array(data.prefix(2)), [0xff, 0xd8])
        let source = try XCTUnwrap(CGImageSourceCreateWithData(data as CFData, nil))
        let properties = try XCTUnwrap(CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [String: Any])
        XCTAssertEqual(properties[kCGImagePropertyPixelWidth as String] as? Int, 1024)
        XCTAssertEqual(properties[kCGImagePropertyPixelHeight as String] as? Int, 512)
    }

    func testInvalidPhotoIsRejected() {
        XCTAssertThrowsError(try NotificationImage.normalize(Data("invalid".utf8)))
    }

    func testPhotoPersistsAndCanBeAttachedAgain() throws {
        var reminder = Reminder()
        reminder.title = "Foto"
        reminder.imageData = try NotificationImage.normalize(samplePhoto())
        let restored = try JSONDecoder().decode(Reminder.self, from: JSONEncoder().encode(reminder))
        XCTAssertEqual(restored.imageData, reminder.imageData)
        for _ in 0..<2 {
            let prepared = try restored.preparedContent()
            XCTAssertEqual(prepared.content.attachments.count, 1)
            XCTAssertEqual(prepared.content.attachments.first?.identifier, "foto")
            prepared.cleanup()
        }
    }

    func testVersionOneDataStillLoadsWithoutPhoto() throws {
        var old = Reminder()
        old.title = "Antigo"
        let encoded = try JSONEncoder().encode(old)
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: encoded) as? [String: Any])
        object.removeValue(forKey: "imageData")
        let legacy = try JSONSerialization.data(withJSONObject: object)
        let decoded = try JSONDecoder().decode(Reminder.self, from: legacy)
        XCTAssertNil(decoded.imageData)
        XCTAssertEqual(decoded.id, old.id)
        let prepared = try decoded.preparedContent()
        XCTAssertTrue(prepared.content.attachments.isEmpty)
        prepared.cleanup()
    }

    func testIconChoicesUseNilForThePrimaryIcon() {
        for primary in AppIconChoice.allCases {
            for choice in AppIconChoice.allCases {
                XCTAssertEqual(choice.alternateName(primary: primary.rawValue), choice == primary ? nil : choice.rawValue)
            }
        }
    }

    func testIconPreviewsAndAlternatesAreBundled() throws {
        XCTAssertEqual(AppIconChoice.primary(), "AppIcon")
        for choice in AppIconChoice.allCases {
            XCTAssertNotNil(UIImage(named: choice.preview), choice.preview)
        }
        let icons = try XCTUnwrap(Bundle.main.object(forInfoDictionaryKey: "CFBundleIcons") as? [String: Any])
        let alternates = try XCTUnwrap(icons["CFBundleAlternateIcons"] as? [String: Any])
        XCTAssertNotNil(alternates["IconWhatsApp"])
        XCTAssertNotNil(alternates["IconItau"])
    }
}
