import SwiftUI
import UIKit

enum AppIconChoice: String, CaseIterable, Identifiable {
    case original = "AppIcon"
    case green = "IconWhatsApp"
    case orange = "IconItau"
    var id: String { rawValue }
    var label: String {
        switch self {
        case .original: return "Notifica original"
        case .green: return "Imagem do WhatsApp"
        case .orange: return "Imagem do Itaú"
        }
    }
    var preview: String { "Preview" + rawValue }
    static func primary(in bundle: Bundle = .main) -> String {
        let icons = bundle.object(forInfoDictionaryKey: "CFBundleIcons") as? [String: Any]
        let primary = icons?["CFBundlePrimaryIcon"] as? [String: Any]
        return primary?["CFBundleIconName"] as? String ?? AppIconChoice.original.rawValue
    }
    func alternateName(primary: String) -> String? {
        rawValue == primary ? nil : rawValue
    }
}

struct IconSettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var selected = UIApplication.shared.alternateIconName ?? AppIconChoice.primary()
    @State private var changing = false
    @State private var errorMessage: String?

    var body: some View {
        NavigationStack {
            List {
                Section {
                    ForEach(AppIconChoice.allCases) { choice in
                        Button {
                            change(to: choice)
                        } label: {
                            HStack(spacing: 16) {
                                Image(choice.preview).resizable().scaledToFit()
                                    .frame(width: 58, height: 58)
                                    .clipShape(RoundedRectangle(cornerRadius: 13))
                                Text(choice.label).foregroundStyle(.primary)
                                Spacer()
                                if selected == choice.rawValue {
                                    Image(systemName: "checkmark.circle.fill").foregroundStyle(.purple)
                                }
                            }.padding(.vertical, 5)
                        }.disabled(changing || !UIApplication.shared.supportsAlternateIcons)
                    }
                } header: { Text("Escolha o ícone") } footer: {
                    Text("A escolha vale para o aplicativo inteiro. O iOS pode manter o ícone principal nas notificações. Nesse caso, instale o IPA com a imagem desejada como ícone principal.")
                }
                Section {
                    Text("O aplicativo continua se chamando Notifica. Não é possível escolher um ícone de origem diferente para cada agendamento.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                if changing { ProgressView("Alterando ícone…") }
            }
            .navigationTitle("Ícone do app")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Pronto") { dismiss() }.disabled(changing) } }
            .interactiveDismissDisabled(changing)
            .alert("Não foi possível trocar o ícone", isPresented: Binding(get: { errorMessage != nil }, set: { if !$0 { errorMessage = nil } })) {
                Button("OK", role: .cancel) { errorMessage = nil }
            } message: { Text(errorMessage ?? "") }
        }.tint(.purple)
    }

    private func change(to choice: AppIconChoice) {
        guard selected != choice.rawValue else { return }
        changing = true
        UIApplication.shared.setAlternateIconName(choice.alternateName(primary: AppIconChoice.primary())) { error in
            Task { @MainActor in
                changing = false
                if let error { errorMessage = error.localizedDescription }
                else { selected = UIApplication.shared.alternateIconName ?? AppIconChoice.primary() }
            }
        }
    }
}
