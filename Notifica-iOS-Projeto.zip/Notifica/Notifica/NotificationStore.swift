import SwiftUI
import Combine
import UserNotifications

@MainActor
final class NotificationStore: NSObject, ObservableObject, UNUserNotificationCenterDelegate {
    @Published private(set) var reminders: [Reminder] = []
    @Published private(set) var pending: Set<String> = []
    @Published private(set) var authorization: UNAuthorizationStatus = .notDetermined
    @Published private(set) var busy = false
    @Published var errorMessage: String?

    private let center = UNUserNotificationCenter.current()
    private let storageKey = "avisos.reminders.v1"
    private let testID = "avisos.test"
    private let storageURL = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        .appendingPathComponent("Avisos", isDirectory: true).appendingPathComponent("reminders.json")

    override init() {
        super.init()
        center.delegate = self
        do {
            let data: Data?
            if FileManager.default.fileExists(atPath: storageURL.path) {
                data = try Data(contentsOf: storageURL)
            } else {
                data = UserDefaults.standard.data(forKey: storageKey)
            }
            if let data { reminders = try JSONDecoder().decode([Reminder].self, from: data) }
        } catch { errorMessage = "Não foi possível ler seus agendamentos salvos. Novos agendamentos só serão salvos após você confirmar uma alteração." }
    }

    func refresh() async {
        authorization = await center.notificationSettings().authorizationStatus
        pending = Set(await center.pendingNotificationRequests().map(\.identifier))
    }

    func requestPermission() async throws {
        await refresh()
        if authorization == .notDetermined {
            _ = try await center.requestAuthorization(options: [.alert, .sound, .badge])
            await refresh()
        }
        guard authorization == .authorized || authorization == .provisional || authorization == .ephemeral else {
            throw AppError("As notificações estão desativadas. Abra os Ajustes e permita notificações para o Avisos.")
        }
    }

    private func persist(_ next: [Reminder]) throws {
        let data = try JSONEncoder().encode(next)
        try FileManager.default.createDirectory(at: storageURL.deletingLastPathComponent(), withIntermediateDirectories: true)
        try data.write(to: storageURL, options: .atomic)
        UserDefaults.standard.removeObject(forKey: storageKey)
        reminders = next
    }

    func save(_ reminder: Reminder) async throws {
        guard !busy else { throw AppError("Aguarde a operação atual terminar.") }
        busy = true
        defer { busy = false }
        try reminder.validate()
        var next = reminders.filter { $0.id != reminder.id }
        next.append(reminder)
        let previous = reminders
        if reminder.enabled {
            try await requestPermission()
            let requests = await center.pendingNotificationRequests()
            let others = requests.filter { $0.identifier != reminder.identifier }.count
            guard others < 60 else { throw AppError("Limite de 60 notificações agendadas. Exclua ou pause uma antes de adicionar outra.") }
            let prepared = try reminder.preparedContent()
            defer { prepared.cleanup() }
            try persist(next)
            do {
                try await center.add(UNNotificationRequest(identifier: reminder.identifier, content: prepared.content, trigger: reminder.trigger()))
            } catch {
                let schedulingError = error
                try persist(previous)
                throw schedulingError
            }
        } else {
            try persist(next)
            center.removePendingNotificationRequests(withIdentifiers: [reminder.identifier])
        }
        await refresh()
    }

    func toggle(_ reminder: Reminder) async {
        var changed = reminder
        changed.enabled.toggle()
        do { try await save(changed) }
        catch { errorMessage = error.localizedDescription }
    }

    func delete(_ reminder: Reminder) async {
        guard !busy else { return }
        busy = true
        defer { busy = false }
        do {
            try persist(reminders.filter { $0.id != reminder.id })
            center.removePendingNotificationRequests(withIdentifiers: [reminder.identifier])
            center.removeDeliveredNotifications(withIdentifiers: [reminder.identifier])
            await refresh()
        } catch { errorMessage = error.localizedDescription }
    }

    func test(title: String = "Funcionou! 🔔", message: String = "Sua notificação personalizada chegou.", sound: Bool = true, imageData: Data? = nil) async throws {
        guard !busy else { throw AppError("Aguarde a operação atual terminar.") }
        busy = true
        defer { busy = false }
        try await requestPermission()
        let content = UNMutableNotificationContent()
        content.title = title.isEmpty ? "Avisos" : String(title.prefix(100))
        content.body = String(message.prefix(1000))
        content.sound = sound ? .default : nil
        let prepared = try PreparedNotification(content: content, imageData: imageData)
        defer { prepared.cleanup() }
        try await center.add(UNNotificationRequest(identifier: testID, content: prepared.content, trigger: UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)))
        await refresh()
    }

    nonisolated func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .list, .sound])
        Task { @MainActor [weak self] in await self?.refresh() }
    }

    nonisolated func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        Task { @MainActor [weak self] in
            await self?.refresh()
            completionHandler()
        }
    }
}
