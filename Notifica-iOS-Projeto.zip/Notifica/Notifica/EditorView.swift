import SwiftUI

struct EditorView: View {
    @EnvironmentObject private var store: NotificationStore
    @Environment(\.dismiss) private var dismiss
    @State private var draft: Reminder
    @State private var errorMessage: String?
    @State private var testSent = false
    @State private var saving = false

    init(initial: Reminder) { _draft = State(initialValue: initial) }

    var body: some View {
        NavigationStack {
            Form {
                Section("Sua mensagem") {
                    TextField("Título", text: $draft.title).onChange(of: draft.title) { draft.title = String($0.prefix(100)) }
                    TextField("Mensagem (opcional)", text: $draft.message, axis: .vertical)
                        .lineLimit(3...6).onChange(of: draft.message) { draft.message = String($0.prefix(1000)) }
                }
                Section {
                    Picker("Repetir", selection: $draft.repeatRule) {
                        ForEach(RepeatRule.allCases) { Text($0.label).tag($0) }
                    }
                    if draft.repeatRule == .daily {
                        DatePicker("Horário", selection: $draft.date, displayedComponents: .hourAndMinute)
                    } else {
                        DatePicker(draft.repeatRule == .weekly ? "Dia da semana e horário" : "Quando", selection: $draft.date, displayedComponents: [.date, .hourAndMinute])
                    }
                    Toggle("Tocar som", isOn: $draft.sound)
                    Toggle("Agendamento ativo", isOn: $draft.enabled)
                } header: { Text("Agendamento") } footer: {
                    if draft.repeatRule == .weekly {
                        Text("Repete toda \(draft.date.formatted(.dateTime.weekday(.wide))) no horário escolhido, a partir da próxima ocorrência.")
                    } else if draft.repeatRule == .daily {
                        Text("Repete no horário escolhido, a partir da próxima ocorrência.")
                    }
                }
                Section("Prévia") {
                    HStack(alignment: .top, spacing: 12) {
                        Image(systemName: "bell.fill").foregroundStyle(.white).padding(9).background(.purple, in: RoundedRectangle(cornerRadius: 10))
                        VStack(alignment: .leading, spacing: 5) {
                            HStack { Text("NOTIFICA").font(.caption2.bold()).foregroundStyle(.secondary); Spacer(); Text("agora").font(.caption2).foregroundStyle(.secondary) }
                            Text(draft.title.isEmpty ? "Seu título aqui" : draft.title).font(.headline)
                            Text(draft.message.isEmpty ? "Sua mensagem aparece aqui." : draft.message).font(.subheadline)
                        }
                    }.padding(.vertical, 8)
                }
                Section {
                    Button {
                        Task {
                            do { try await store.test(title: draft.title, message: draft.message, sound: draft.sound); testSent = true }
                            catch { errorMessage = error.localizedDescription }
                        }
                    } label: { Label("Testar esta mensagem em 5 segundos", systemImage: "paperplane") }
                    .disabled(store.busy || saving)
                } footer: {
                    Text("As notificações aparecem com o nome e o ícone do Notifica. O app não muda notificações de outros aplicativos.")
                }
            }
            .navigationTitle("Personalizar")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { dismiss() }.disabled(saving) }
                ToolbarItem(placement: .confirmationAction) {
                    Button(saving ? "Salvando…" : "Salvar") {
                        saving = true
                        Task {
                            do { try await store.save(draft); dismiss() }
                            catch { errorMessage = error.localizedDescription }
                            saving = false
                        }
                    }.disabled(store.busy || saving || draft.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
            .interactiveDismissDisabled(saving)
            .alert("Confira os dados", isPresented: Binding(get: { errorMessage != nil }, set: { if !$0 { errorMessage = nil } })) {
                Button("OK", role: .cancel) { errorMessage = nil }
            } message: { Text(errorMessage ?? "") }
            .alert("Teste agendado", isPresented: $testSent) {
                Button("OK", role: .cancel) {}
            } message: { Text("Você receberá esta mensagem em 5 segundos.") }
        }
    }
}
