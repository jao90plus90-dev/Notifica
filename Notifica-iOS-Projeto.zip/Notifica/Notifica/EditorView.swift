import SwiftUI
import PhotosUI
import UIKit

struct EditorView: View {
    @EnvironmentObject private var store: NotificationStore
    @Environment(\.dismiss) private var dismiss
    @State private var draft: Reminder
    @State private var errorMessage: String?
    @State private var testSent = false
    @State private var saving = false
    @State private var selectedPhoto: PhotosPickerItem?
    @State private var loadingImage = false

    init(initial: Reminder) { _draft = State(initialValue: initial) }

    var body: some View {
        NavigationStack {
            Form {
                Section("Sua mensagem") {
                    TextField("Título", text: $draft.title).onChange(of: draft.title) { draft.title = String($0.prefix(100)) }
                    TextField("Mensagem (opcional)", text: $draft.message, axis: .vertical)
                        .lineLimit(3...6).onChange(of: draft.message) { draft.message = String($0.prefix(1000)) }
                }
                Section {
                    PhotosPicker(selection: $selectedPhoto, matching: .images, photoLibrary: .shared()) {
                        Label(draft.imageData == nil ? "Escolher foto" : "Trocar foto", systemImage: "photo.on.rectangle")
                    }.disabled(saving || store.busy)
                    if loadingImage { ProgressView("Preparando imagem…") }
                    if let data = draft.imageData, let image = UIImage(data: data) {
                        Image(uiImage: image).resizable().scaledToFit()
                            .frame(maxWidth: .infinity, maxHeight: 210)
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                            .accessibilityLabel("Foto selecionada para a notificação")
                        Button(role: .destructive) {
                            selectedPhoto = nil
                            draft.imageData = nil
                            loadingImage = false
                        } label: { Label("Remover foto", systemImage: "trash") }
                        .disabled(saving || store.busy)
                    }
                } header: { Text("Imagem da notificação") } footer: {
                    Text("A foto aparece como anexo. Toque e segure a notificação para ampliá-la. Para mudar o ícone do app, use o botão de ícone na tela inicial.")
                }
                Section {
                    Picker("Repetir", selection: $draft.repeatRule) {
                        ForEach(RepeatRule.allCases) { Text($0.label).tag($0) }
                    }
                    if draft.repeatRule == .daily {
                        DatePicker("Horário", selection: $draft.date, displayedComponents: .hourAndMinute)
                    } else {
                        DatePicker(draft.repeatRule == .weekly ? "Dia da semana e horário" : "Quando", selection: $draft.date, displayedComponents: [.date, .hourAndMinute])
                    }
                    Toggle("Tocar som", isOn: $draft.sound)
                    Toggle("Agendamento ativo", isOn: $draft.enabled)
                } header: { Text("Agendamento") } footer: {
                    if draft.repeatRule == .weekly {
                        Text("Repete toda \(draft.date.formatted(.dateTime.weekday(.wide))) no horário escolhido, a partir da próxima ocorrência.")
                    } else if draft.repeatRule == .daily {
                        Text("Repete no horário escolhido, a partir da próxima ocorrência.")
                    }
                }
                Section("Prévia") {
                    HStack(alignment: .top, spacing: 12) {
                        Image(systemName: "bell.fill").foregroundStyle(.white).padding(9).background(.purple, in: RoundedRectangle(cornerRadius: 10))
                        VStack(alignment: .leading, spacing: 5) {
                            HStack { Text("NOTIFICA").font(.caption2.bold()).foregroundStyle(.secondary); Spacer(); Text("agora").font(.caption2).foregroundStyle(.secondary) }
                            Text(draft.title.isEmpty ? "Seu título aqui" : draft.title).font(.headline)
                            Text(draft.message.isEmpty ? "Sua mensagem aparece aqui." : draft.message).font(.subheadline)
                        }
                        if let data = draft.imageData, let image = UIImage(data: data) {
                            Image(uiImage: image).resizable().scaledToFill().frame(width: 56, height: 56)
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                                .accessibilityLabel("Miniatura da foto")
                        }
                    }.padding(.vertical, 8)
                }
                Section {
                    Button {
                        Task {
                            do { try await store.test(title: draft.title, message: draft.message, sound: draft.sound, imageData: draft.imageData); testSent = true }
                            catch { errorMessage = error.localizedDescription }
                        }
                    } label: { Label("Testar esta mensagem em 5 segundos", systemImage: "paperplane") }
                    .disabled(store.busy || saving || loadingImage)
                } footer: {
                    Text("As notificações aparecem com o nome Notifica e o ícone definido pelo iOS para esta versão do app.")
                }
            }
            .navigationTitle("Personalizar")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { dismiss() }.disabled(saving) }
                ToolbarItem(placement: .confirmationAction) {
                    Button(saving ? "Salvando…" : "Salvar") {
                        saving = true
                        Task {
                            do { try await store.save(draft); dismiss() }
                            catch { errorMessage = error.localizedDescription }
                            saving = false
                        }
                    }.disabled(store.busy || saving || loadingImage || draft.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
            .interactiveDismissDisabled(saving)
            .task(id: selectedPhoto) {
                guard let item = selectedPhoto else { return }
                loadingImage = true
                defer { if selectedPhoto == item { loadingImage = false } }
                do {
                    guard let original = try await item.loadTransferable(type: Data.self) else {
                        throw AppError("Não foi possível carregar a foto. Se ela estiver no iCloud, confira sua conexão.")
                    }
                    let normalized = try await Task.detached(priority: .userInitiated) {
                        try NotificationImage.normalize(original)
                    }.value
                    try Task.checkCancellation()
                    guard selectedPhoto == item else { return }
                    draft.imageData = normalized
                } catch is CancellationError {
                    // Keep the previous photo when a newer selection replaces this task.
                } catch {
                    if selectedPhoto == item { errorMessage = error.localizedDescription }
                }
            }
            .alert("Confira os dados", isPresented: Binding(get: { errorMessage != nil }, set: { if !$0 { errorMessage = nil } })) {
                Button("OK", role: .cancel) { errorMessage = nil }
            } message: { Text(errorMessage ?? "") }
            .alert("Teste agendado", isPresented: $testSent) {
                Button("OK", role: .cancel) {}
            } message: { Text("Você receberá esta mensagem em 5 segundos.") }
        }
    }
}
