import Foundation
import ImageIO
import UniformTypeIdentifiers
import UserNotifications

enum NotificationImage {
    static func normalize(_ data: Data) throws -> Data {
        guard data.count <= 30 * 1024 * 1024,
              let source = CGImageSourceCreateWithData(data as CFData, nil),
              let image = CGImageSourceCreateThumbnailAtIndex(source, 0, [
                kCGImageSourceCreateThumbnailFromImageAlways: true,
                kCGImageSourceCreateThumbnailWithTransform: true,
                kCGImageSourceThumbnailMaxPixelSize: 1024,
                kCGImageSourceShouldCacheImmediately: true
              ] as CFDictionary) else {
            throw AppError("Não foi possível abrir esta foto. Escolha outra imagem de até 30 MB.")
        }
        let output = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(output, UTType.jpeg.identifier as CFString, 1, nil) else {
            throw AppError("Não foi possível preparar a imagem.")
        }
        CGImageDestinationAddImage(destination, image, [kCGImageDestinationLossyCompressionQuality: 0.8] as CFDictionary)
        guard CGImageDestinationFinalize(destination) else {
            throw AppError("Não foi possível salvar a imagem.")
        }
        return output as Data
    }
}

struct PreparedNotification {
    let content: UNMutableNotificationContent
    private let directory: URL?

    init(content: UNMutableNotificationContent, imageData: Data?) throws {
        self.content = content
        guard let imageData else { directory = nil; return }
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent("avisos-" + UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        do {
            let file = folder.appendingPathComponent("foto.jpg")
            try imageData.write(to: file, options: .atomic)
            content.attachments = [try UNNotificationAttachment(identifier: "foto", url: file, options: nil)]
            directory = folder
        } catch {
            try? FileManager.default.removeItem(at: folder)
            throw error
        }
    }

    // The notification center owns its copy after add() finishes. Preserve the
    // original photo in Reminder so editing, tests and recurring schedules work.
    func cleanup() {
        if let directory { try? FileManager.default.removeItem(at: directory) }
    }
}
