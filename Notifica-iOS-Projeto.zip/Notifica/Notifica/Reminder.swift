import Foundation
import UserNotifications

enum RepeatRule: String, Codable, CaseIterable, Identifiable {
    case once, daily, weekly
    var id: String { rawValue }
    var label: String {
        switch self {
        case .once: return "Uma vez"
        case .daily: return "Todos os dias"
        case .weekly: return "Toda semana"
        }
    }
}

struct Reminder: Identifiable, Codable, Equatable {
    var id = UUID()
    var title = ""
    var message = ""
    var date = Date().addingTimeInterval(300)
    var repeatRule: RepeatRule = .once
    var sound = true
    var enabled = true

    var identifier: String { id.uuidString }

    func validate(now: Date = Date()) throws {
        guard !title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw AppError("Escreva um título para a notificação.")
        }
        guard title.count <= 100, message.count <= 1000 else {
            throw AppError("Use até 100 caracteres no título e 1.000 na mensagem.")
        }
        if enabled && repeatRule == .once && date <= now {
            throw AppError("Escolha uma data e um horário no futuro.")
        }
    }

    func trigger(calendar: Calendar = .current) -> UNCalendarNotificationTrigger {
        let fields: Set<Calendar.Component>
        switch repeatRule {
        case .once: fields = [.year, .month, .day, .hour, .minute, .second]
        case .daily: fields = [.hour, .minute]
        case .weekly: fields = [.weekday, .hour, .minute]
        }
        let components = calendar.dateComponents(fields, from: date)
        return UNCalendarNotificationTrigger(dateMatching: components, repeats: repeatRule != .once)
    }

    func content() -> UNMutableNotificationContent {
        let content = UNMutableNotificationContent()
        content.title = title.trimmingCharacters(in: .whitespacesAndNewlines)
        content.body = message.trimmingCharacters(in: .whitespacesAndNewlines)
        content.sound = sound ? .default : nil
        return content
    }
}

struct AppError: LocalizedError {
    let message: String
    init(_ message: String) { self.message = message }
    var errorDescription: String? { message }
}
