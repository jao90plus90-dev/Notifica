import SwiftUI

@main
struct AvisosApp: App {
    @StateObject private var store = NotificationStore()
    var body: some Scene {
        WindowGroup {
            HomeView()
                .environmentObject(store)
                .tint(.orange)
                .preferredColorScheme(.dark)
        }
    }
}
