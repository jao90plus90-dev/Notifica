import SwiftUI

@main
struct NotificaApp: App {
    @StateObject private var store = NotificationStore()
    var body: some Scene {
        WindowGroup {
            HomeView()
                .environmentObject(store)
                .tint(.purple)
                .preferredColorScheme(.dark)
        }
    }
}
