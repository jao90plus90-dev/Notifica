import SwiftUI
import UserNotifications

struct HomeView: View {
    @EnvironmentObject private var store: NotificationStore
    @Environment(\.scenePhase) private var scenePhase
    @State private var editor: Reminder?
    @State private var testSent = false

    private var activeCount: Int {
        store.reminders.filter { store.pending.contains($0.identifier) }.count
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    VStack(alignment: .leading, spacing: 14) {
                        Image(systemName: "bell.badge.fill")
                            .font(.system(size: 32)).foregroundStyle(.white)
                            .padding(16).background(.white.opacity(0.15), in: RoundedRectangle(cornerRadius: 22))
                        Text("Um toque,\nna hora certa.")
                            .font(.system(size: 34, weight: .bold, design: .rounded))
                        Text("Suas mensagens. Seu horário.")
                            .foregroundStyle(.white.opacity(0.8))
                        HStack {
                            Label("\(activeCount) agendada\(activeCount == 1 ? "" : "s")", systemImage: "clock")
                            Spacer()
                            Text("NO SEU IPHONE").font(.caption2.bold())
                        }.font(.subheadline).padding(.top, 8)
                    }
                    .padding(24).frame(maxWidth: .infinity, alignment: .leading)
                    .background(LinearGradient(colors: [Color(red: 0.40, green: 0.22, blue: 0.82), Color(red: 0.23, green: 0.12, blue: 0.50)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 28))

                    if store.authorization != .authorized && store.authorization != .provisional && store.authorization != .ephemeral {
                        permissionCard
                    }

                    HStack {
                        Text("Minhas notificações").font(.title3.bold())
                        Spacer()
                        Text("\(store.reminders.count)").foregroundStyle(.secondary)
                    }

                    if store.reminders.isEmpty {
                        VStack(spacing: 12) {
                            Image(systemName: "sparkles").font(.largeTitle).foregroundStyle(.purple)
                            Text("Sua primeira notificação").font(.headline)
                            Text("Lembre-se de beber água, estudar ou fazer uma pausa. Você escolhe a mensagem.")
                                .foregroundStyle(.secondary).multilineTextAlignment(.center)
                            Button("Criar notificação") { editor = Reminder() }
                                .buttonStyle(.borderedProminent)
                        }.frame(maxWidth: .infinity).padding(26).background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 22))
                    } else {
                        ForEach(store.reminders.sorted { $0.date < $1.date }) { reminder in
                            reminderCard(reminder)
                        }
                    }

                    Button {
                        Task {
                            do { try await store.test(); testSent = true }
                            catch { store.errorMessage = error.localizedDescription }
                        }
                    } label: {
                        Label("Enviar teste em 5 segundos", systemImage: "paperplane")
                            .frame(maxWidth: .infinity).padding(8)
                    }.buttonStyle(.bordered).disabled(store.busy)

                    Text("O iOS entrega as notificações mesmo com o app fechado. Modo Foco, resumo agendado e ajustes de som podem mudar quando e como elas aparecem.")
                        .font(.footnote).foregroundStyle(.secondary)
                }.padding(20)
            }
            .background(Color(red: 0.055, green: 0.055, blue: 0.08))
            .navigationTitle("Notifica")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { editor = Reminder() } label: { Image(systemName: "plus.circle.fill").font(.title2) }
                        .accessibilityLabel("Criar notificação")
                        .disabled(store.busy)
                }
            }
            .sheet(item: $editor) { reminder in EditorView(initial: reminder).environmentObject(store) }
            .task { await store.refresh() }
            .onChange(of: scenePhase) { phase in
                if phase == .active { Task { await store.refresh() } }
            }
            .alert("Não foi possível concluir", isPresented: Binding(get: { store.errorMessage != nil }, set: { if !$0 { store.errorMessage = nil } })) {
                Button("OK", role: .cancel) { store.errorMessage = nil }
            } message: { Text(store.errorMessage ?? "") }
            .alert("Teste agendado", isPresented: $testSent) {
                Button("OK", role: .cancel) {}
            } message: { Text("A notificação chega em 5 segundos. Você pode bloquear a tela para conferir.") }
        }
    }

    private var permissionCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("Permita as notificações", systemImage: "bell.slash").font(.headline)
            Text("Autorize o Notifica a exibir suas mensagens.").font(.subheadline).foregroundStyle(.secondary)
            Button(store.authorization == .denied ? "Abrir Ajustes" : "Permitir notificações") {
                if store.authorization == .denied {
                    if let url = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(url) }
                } else {
                    Task {
                        do { try await store.requestPermission() }
                        catch { store.errorMessage = error.localizedDescription }
                    }
                }
            }.buttonStyle(.bordered)
        }.padding(18).frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.orange.opacity(0.09), in: RoundedRectangle(cornerRadius: 20))
    }

    private func reminderCard(_ reminder: Reminder) -> some View {
        let scheduled = store.pending.contains(reminder.identifier)
        let status = !reminder.enabled ? "Pausada" : scheduled ? "Agendada" : "Sem agendamento"
        return VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .top) {
                Image(systemName: reminder.sound ? "bell.fill" : "bell.slash.fill")
                    .foregroundStyle(.purple).padding(10).background(.purple.opacity(0.12), in: RoundedRectangle(cornerRadius: 12))
                VStack(alignment: .leading, spacing: 4) {
                    Text(reminder.title).font(.headline)
                    if !reminder.message.isEmpty { Text(reminder.message).font(.subheadline).foregroundStyle(.secondary).lineLimit(3) }
                }
                Spacer(minLength: 0)
                Menu {
                    Button { editor = reminder } label: { Label("Editar", systemImage: "pencil") }
                    Button {
                        Task { await store.toggle(reminder) }
                    } label: { Label(reminder.enabled ? "Pausar" : "Ativar", systemImage: reminder.enabled ? "pause" : "play") }
                    Button(role: .destructive) { Task { await store.delete(reminder) } } label: { Label("Excluir", systemImage: "trash") }
                } label: { Image(systemName: "ellipsis").padding(8) }
                .disabled(store.busy).accessibilityLabel("Opções de \(reminder.title)")
            }
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text(scheduleLabel(reminder)).font(.caption).foregroundStyle(.secondary)
                    Text(status).font(.caption2.bold()).foregroundStyle(scheduled ? Color.green : Color.secondary)
                }
                Spacer()
                Text(reminder.date, style: .time).font(.system(.title3, design: .rounded).bold()).monospacedDigit()
            }
        }.padding(18).background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 22))
    }

    private func scheduleLabel(_ reminder: Reminder) -> String {
        switch reminder.repeatRule {
        case .once: return reminder.date.formatted(date: .abbreviated, time: .omitted)
        case .daily: return "Todos os dias"
        case .weekly: return "Toda semana • " + reminder.date.formatted(.dateTime.weekday(.wide))
        }
    }
}
