# Avisos — versão laranja 1.3.0 (4)

App pessoal de notificações locais com título, mensagem, foto e agendamento.
A imagem laranja é o único ícone principal incluído. Não há ícones alternativos nem seletor.
O identificador br.pessoal.avisos.laranja cria uma instalação independente para evitar o cache do ícone anterior.
Instale Avisos-Laranja.ipa pelo SideStore/AltStore e permita notificações.
Os agendamentos anteriores não são transferidos: anote-os antes de remover o app antigo.
Desative as notificações do app antigo para que seus agendamentos não continuem aparecendo.

O projeto e o esquema de compilação mantêm o nome interno Notifica para compatibilidade com o workflow existente.
O produto instalado, executável, módulo, nome exibido e dados locais usam Avisos.
Compile no macOS com Xcode e XcodeGen executando scripts/build-ipa.sh.
