# Notifica para iPhone

## Versão 1.2 — ícones incluídos

Toque no botão de ícone no canto superior esquerdo da tela inicial para escolher
entre Notifica original e as duas imagens fornecidas pelo usuário. A troca vale
para o aplicativo inteiro. O iOS pode manter o ícone principal nas notificações,
por isso a compilação também gera `Notifica-Icone-Verde.ipa` e
`Notifica-Icone-Laranja.ipa`, com essas imagens como ícones principais.
Os três IPAs têm o mesmo identificador; instale somente a versão desejada, por
cima da anterior com a mesma conta Apple. Não são aplicativos oficiais das marcas.
O nome visível continua sendo Notifica. Não há troca por agendamento.

## Versão 1.1 — fotos nas notificações

No editor, use **Imagem da notificação → Escolher foto**. Você pode trocar ou
remover a imagem, conferir a prévia e enviar um teste em 5 segundos com a foto.
Toque e segure a notificação recebida para ampliar o anexo. A apresentação exata
depende do iOS; o ícone pequeno continua sendo o do Notifica.

As fotos escolhidas ficam no próprio iPhone e são reduzidas para JPEG de até
1024 pixels. O app acessa somente a foto escolhida pelo seletor do sistema.
Esta atualização mantém o identificador do aplicativo e lê os agendamentos da
versão anterior. Instale por cima com a mesma conta Apple para preservar os dados.

App pessoal em português para criar notificações locais com título, mensagem,
data, horário, som opcional e repetição única, diária ou semanal. Inclui prévia,
teste em 5 segundos, edição, pausa, exclusão e armazenamento no iPhone.
Compatível com iOS 16 ou superior. Não exige servidor, login nem internet para
agendar e receber as notificações.

## Estado desta entrega

Este pacote contém o código-fonte e a rotina de compilação. NÃO contém um IPA
compilado: o ambiente em que o projeto foi criado é Linux e não possui Xcode.
Os testes XCTest estão incluídos, mas precisam ser executados no macOS.
A configuração de compilação ainda precisa passar pela primeira execução no GitHub.

## Gerar o IPA sem possuir Mac

1. Crie um repositório no GitHub, com a branch padrão `main`.
2. Extraia este ZIP. Envie o CONTEÚDO da pasta `Notifica` para a raiz do repositório,
   incluindo `.github/workflows/build-ios.yml`. Ative a exibição de arquivos ocultos
   se necessário. `project.yml` deve ficar na raiz, não dentro de outra pasta.
3. Abra a aba **Actions**, escolha **Compilar IPA** e clique em **Run workflow**.
   O envio inicial para `main` também inicia a rotina automaticamente.
4. A rotina gera o projeto, executa os testes no simulador, compila para iPhone
   e empacota o aplicativo sem assinatura.
5. Quando terminar com sucesso, baixe o artefato **Notifica-IPA** e extraia
   `Notifica.ipa` de dentro dele.
6. Transfira o IPA para o iPhone e importe na **AltStore Classic**. Ela fará a
   assinatura com sua conta Apple. O IPA não assinado não instala só ao tocar nele.

Não é necessário colocar senha da Apple nem certificado no GitHub. Recursos
gratuitos ou cobrança do GitHub Actions dependem do plano e das cotas da sua conta.
Uma conta Apple gratuita exige renovação periódica da assinatura pela AltStore.

## Usar

Abra o Notifica, permita notificações e toque em **+**. Digite o título e a mensagem,
escolha a repetição e o horário e salve. Para testar, toque em **Enviar teste em
5 segundos**. No menu de cada cartão você pode editar, pausar ou excluir.

As notificações são sempre identificadas como **Notifica**, com seu próprio ícone.
O app não envia notificações como WhatsApp, Instagram ou outros aplicativos.
A prévia é ilustrativa; o visual final depende do iOS. Modo Foco, resumo agendado,
modo silencioso e permissões podem silenciar ou atrasar a exibição. Não é um alarme
crítico e não ignora esses ajustes.

Na repetição semanal, a data seleciona o dia da semana; a notificação começa na
próxima ocorrência desse dia e horário. No modo diário vale a próxima ocorrência
do horário, independentemente da data original. O agendamento usa o horário local
do aparelho. Até 60 agendamentos simultâneos são aceitos pelo app.

Se um agendamento único aparecer como **Sem agendamento**, ele pode já ter sido
entregue. Edite-o e escolha uma nova data futura para reutilizá-lo. A lista é
mantida no aparelho; desinstalar o app pode apagar seus dados e agendamentos.

## Compilar em Mac

Instale o Xcode, as ferramentas de linha de comando e o XcodeGen (`brew install
xcodegen`). Execute `bash scripts/build-ipa.sh`. O arquivo será `build/Notifica.ipa`.

## Verificação

O workflow executa seis testes XCTest cobrindo validação de título e data,
tamanho de mensagem, componentes de datas únicas e recorrentes, conteúdo sem som
e persistência JSON. Entrega de notificações e permissões ainda precisam ser
conferidas em um iPhone real após a instalação.
