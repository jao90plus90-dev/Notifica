#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! command -v xcodebuild >/dev/null; then
  echo "É necessário executar este script no macOS com Xcode. Use o workflow do GitHub Actions."
  exit 1
fi
if ! command -v xcodegen >/dev/null; then
  echo "Instale o XcodeGen: brew install xcodegen"
  exit 1
fi
xcodegen generate
build_variant() {
  local icon_name="$1" output_name="$2" alternate_names="$3"
  xcodebuild -project Notifica.xcodeproj -scheme Notifica -configuration Release \
    -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build/device \
    CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY='' \
    "ASSETCATALOG_COMPILER_APPICON_NAME=$icon_name" \
    "ASSETCATALOG_COMPILER_ALTERNATE_APPICON_NAMES=$alternate_names" build
  local app_path='build/device/Build/Products/Release-iphoneos/Notifica.app'
  test -f "$app_path/Notifica"
  mkdir -p build/ipa/Payload
  rm -rf build/ipa/Payload/Notifica.app
  cp -R "$app_path" build/ipa/Payload/Notifica.app
  rm -rf build/ipa/Payload/Notifica.app/_CodeSignature
  rm -f build/ipa/Payload/Notifica.app/embedded.mobileprovision
  rm -f "build/$output_name"
  (cd build/ipa && /usr/bin/zip -qry "../$output_name" Payload)
  echo "IPA sem assinatura criado em build/$output_name"
}
build_variant AppIcon Notifica.ipa 'IconWhatsApp IconItau'
build_variant IconWhatsApp Notifica-Icone-Verde.ipa 'AppIcon IconItau'
build_variant IconItau Notifica-Icone-Laranja.ipa 'AppIcon IconWhatsApp'
