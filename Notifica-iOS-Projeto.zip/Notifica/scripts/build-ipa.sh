#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! command -v xcodebuild >/dev/null; then
  echo "É necessário executar este script no macOS com Xcode. Use o workflow do GitHub Actions."
  exit 1
fi
if ! command -v xcodegen >/dev/null; then
  echo "Instale o XcodeGen: brew install xcodegen"
  exit 1
fi
xcodegen generate
xcodebuild -project Notifica.xcodeproj -scheme Notifica -configuration Release \
  -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build/device \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY='' build
app_path='build/device/Build/Products/Release-iphoneos/Avisos.app'
test -f "$app_path/Avisos"
rm -rf build/ipa
mkdir -p build/ipa/Payload
cp -R "$app_path" build/ipa/Payload/Avisos.app
rm -rf build/ipa/Payload/Avisos.app/_CodeSignature
rm -f build/ipa/Payload/Avisos.app/embedded.mobileprovision
rm -f build/*.ipa
(cd build/ipa && /usr/bin/zip -qry ../Avisos-Laranja.ipa Payload)
echo "IPA sem assinatura criado em build/Avisos-Laranja.ipa"
