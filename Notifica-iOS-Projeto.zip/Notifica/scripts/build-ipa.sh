#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! command -v xcodebuild >/dev/null; then
  echo "É necessário executar este script no macOS com Xcode. Use o workflow do GitHub Actions."
  exit 1
fi
if ! command -v xcodegen >/dev/null; then
  echo "Instale o XcodeGen: brew install xcodegen"
  exit 1
fi
xcodegen generate
xcodebuild -project Notifica.xcodeproj -scheme Notifica -configuration Release \
  -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build/device \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY='' build
APP_PATH='build/device/Build/Products/Release-iphoneos/Notifica.app'
test -f "$APP_PATH/Notifica"
mkdir -p build/ipa/Payload
rm -rf build/ipa/Payload/Notifica.app
cp -R "$APP_PATH" build/ipa/Payload/Notifica.app
rm -rf build/ipa/Payload/Notifica.app/_CodeSignature
rm -f build/ipa/Payload/Notifica.app/embedded.mobileprovision
rm -f build/Notifica.ipa
(cd build/ipa && /usr/bin/zip -qry ../Notifica.ipa Payload)
echo "IPA sem assinatura criado em build/Notifica.ipa. Instale e assine com AltStore Classic."
